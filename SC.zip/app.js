/**
 * Swapnil Chemicals - front-end application
 * Vanilla JS, no build step. Loaded with `defer`, so DOM is parsed already.
 * No inline event handlers are used anywhere (CSP-friendly): everything is
 * wired up here via addEventListener / event delegation.
 */
(function () {
  "use strict";

  /* ============================== Utilities ============================== */

  const qs = (sel, ctx) => (ctx || document).querySelector(sel);
  const qsa = (sel, ctx) => Array.from((ctx || document).querySelectorAll(sel));

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function formatINR(amount) {
    return "₹" + Number(amount).toLocaleString("en-IN");
  }

  function debounce(fn, wait) {
    let t;
    return function (...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  function clamp(n, min, max) {
    return Math.min(Math.max(n, min), max);
  }

  const PLACEHOLDER_IMG =
    "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 150'%3E%3Crect width='200' height='150' fill='%23f1f5f9'/%3E%3Ctext x='50%25' y='50%25' font-family='sans-serif' font-size='14' fill='%2394a3b8' text-anchor='middle' dominant-baseline='middle'%3EImage unavailable%3C/text%3E%3C/svg%3E";

  function withImgFallback(img) {
    img.addEventListener(
      "error",
      () => {
        img.src = PLACEHOLDER_IMG;
      },
      { once: true }
    );
  }

  /* Lightweight toast for quiet confirmations (copy-to-clipboard, voice errors). */
  let toastContainer;
  function showToast(message) {
    if (!toastContainer) {
      toastContainer = document.createElement("div");
      toastContainer.className = "toast-container";
      toastContainer.setAttribute("aria-live", "polite");
      document.body.appendChild(toastContainer);
    }
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = message;
    toastContainer.appendChild(toast);
    setTimeout(() => toast.remove(), 2700);
  }

  async function copyToClipboard(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (err) {
      /* fall through to failure toast below */
    }
    return false;
  }

  const WHATSAPP_NUMBER = "919352470085";
  function waLink(message) {
    return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  }

  /* ============================== Product data ============================== */

  const PRODUCTS = [
    {
      id: "dashboard-polish",
      name: "Dashboard Polish",
      image: "Dashboard Polish.jpeg",
      description: "Premium dashboard polish for long-lasting shine",
      price: 200,
    },
    {
      id: "tyre-polish",
      name: "Tyre Polish",
      image: "Tyre Polish.jpeg",
      description: "High-gloss tyre polish for enhanced appearance",
      price: 150,
    },
    {
      id: "car-foaming-wash",
      name: "Car Foaming Wash",
      image: "Car Foaming Wash.jpeg",
      description: "Advanced foaming wash for thorough cleaning",
      price: 70,
    },
    {
      id: "glass-cleaner",
      name: "Glass Cleaner",
      image: "Glass Cleaner.jpeg",
      description: "Streak-free glass cleaner for crystal clear visibility",
      price: 70,
    },
    {
      id: "interior-cleaner",
      name: "Interior Cleaner",
      image: "Interior Cleaner.png",
      description: "Effective interior cleaner for all surfaces",
      price: 130,
    },
    {
      id: "foaming-gun",
      name: "Foaming Gun",
      image: "Foaming Gun.jpeg",
      description: "Professional foaming gun for car wash",
      price: 2000,
    },
    {
      id: "micro-towel-1",
      name: "Micro Towel",
      image: "Micro Towel.jpg",
      description: "Ultra soft Micro Towel",
      price: 70,
    },
    {
      id: "micro-towel-2",
      name: "Micro Towel",
      image: "Micro Towel 2.jpg",
      description: "Ultra soft Micro Towel",
      price: 110,
    },
    {
      id: "micro-towel-3",
      name: "Micro Towel",
      image: "Micro Towel 3.jpg",
      description: "Ultra soft Micro Towel",
      price: 130,
    },
  ];

  const productById = (id) => PRODUCTS.find((p) => p.id === id);

  /* ============================== Cart state ============================== */

  const CART_KEY = "sc_cart_v1";

  const Cart = {
    items: [], // [{ id, qty }]

    load() {
      try {
        const raw = localStorage.getItem(CART_KEY);
        const parsed = raw ? JSON.parse(raw) : [];
        this.items = Array.isArray(parsed)
          ? parsed.filter((it) => it && productById(it.id) && Number(it.qty) > 0)
          : [];
      } catch (err) {
        this.items = [];
      }
    },

    save() {
      try {
        localStorage.setItem(CART_KEY, JSON.stringify(this.items));
      } catch (err) {
        /* storage may be unavailable (private mode, quota) - cart still works in-memory */
      }
    },

    add(id, qty) {
      const existing = this.items.find((it) => it.id === id);
      if (existing) {
        existing.qty = clamp(existing.qty + qty, 1, 999);
      } else {
        this.items.push({ id, qty: clamp(qty, 1, 999) });
      }
      this.save();
    },

    setQty(id, qty) {
      const existing = this.items.find((it) => it.id === id);
      if (!existing) return;
      existing.qty = clamp(qty, 1, 999);
      this.save();
    },

    remove(id) {
      this.items = this.items.filter((it) => it.id !== id);
      this.save();
    },

    clear() {
      this.items = [];
      this.save();
    },

    count() {
      return this.items.reduce((sum, it) => sum + it.qty, 0);
    },

    lines() {
      return this.items
        .map((it) => {
          const product = productById(it.id);
          if (!product) return null;
          return { ...it, product, lineTotal: product.price * it.qty };
        })
        .filter(Boolean);
    },

    total() {
      return this.lines().reduce((sum, line) => sum + line.lineTotal, 0);
    },
  };

  /* ============================== Header / scroll chrome ============================== */

  function initScrollChrome() {
    const progress = qs("#scrollProgress");
    const toTopBtn = qs("#scrollToTop");

    const onScroll = () => {
      const doc = document.documentElement;
      const scrollable = doc.scrollHeight - doc.clientHeight;
      const pct = scrollable > 0 ? (window.scrollY / scrollable) * 100 : 0;
      if (progress) progress.style.width = pct + "%";
      if (toTopBtn) toTopBtn.classList.toggle("hidden", window.scrollY < 400);
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();

    if (toTopBtn) {
      toTopBtn.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    }

    const yearEl = qs("#copyrightYear");
    if (yearEl) yearEl.textContent = String(new Date().getFullYear());
  }

  /* ============================== Copy-to-clipboard (GST / UPI id) ============================== */

  function initCopyButtons() {
    document.addEventListener("click", async (e) => {
      const btn = e.target.closest("[data-copy]");
      if (!btn) return;
      const ok = await copyToClipboard(btn.getAttribute("data-copy"));
      showToast(ok ? "Copied to clipboard" : "Could not copy - please copy manually");
      if (ok) {
        const icon = btn.querySelector("i");
        if (icon) {
          const original = icon.className;
          icon.className = "fas fa-check text-sm";
          setTimeout(() => {
            icon.className = original;
          }, 1500);
        }
      }
    });
  }

  /* ============================== Product grid + search ============================== */

  function productCardHtml(product) {
    return `
      <article class="product-card" data-id="${product.id}">
        <div class="product-card-media">
          <img src="${encodeURI(product.image)}" alt="${escapeHtml(product.name)}" loading="lazy" decoding="async" />
        </div>
        <div class="product-card-body">
          <h3 class="product-card-title">${escapeHtml(product.name)}</h3>
          <p class="product-card-desc">${escapeHtml(product.description)}</p>
          <div class="product-card-footer">
            <span class="product-card-price">${formatINR(product.price)}</span>
            <div class="product-card-qty" role="group" aria-label="Quantity">
              <button type="button" data-action="dec" aria-label="Decrease quantity">&minus;</button>
              <span data-role="qty">1</span>
              <button type="button" data-action="inc" aria-label="Increase quantity">+</button>
            </div>
          </div>
          <div class="product-card-actions">
            <button type="button" class="btn-add-cart" data-action="add-cart">
              <i class="fas fa-cart-plus" aria-hidden="true"></i> Add to Cart
            </button>
            <button type="button" class="btn-enquire" data-action="enquire">
              <i class="fab fa-whatsapp" aria-hidden="true"></i> Enquiry
            </button>
          </div>
        </div>
      </article>`;
  }

  function renderProducts(list) {
    const grid = qs("#productsGrid");
    if (!grid) return;

    if (!list.length) {
      grid.innerHTML = `
        <div class="no-results">
          <i class="fas fa-magnifying-glass-minus text-3xl mb-3 block opacity-40" aria-hidden="true"></i>
          No products match your search. Try a different term, or
          <a href="#contact" class="text-blue-600 font-semibold">contact us</a> directly.
        </div>`;
      return;
    }

    grid.innerHTML = list.map(productCardHtml).join("");
    qsa("img", grid).forEach(withImgFallback);
  }

  function initProductsGrid() {
    renderProducts(PRODUCTS);

    const grid = qs("#productsGrid");
    if (!grid) return;

    grid.addEventListener("click", (e) => {
      const card = e.target.closest(".product-card");
      if (!card) return;
      const product = productById(card.dataset.id);
      if (!product) return;
      const qtyEl = card.querySelector('[data-role="qty"]');
      const actionBtn = e.target.closest("[data-action]");
      if (!actionBtn) return;

      switch (actionBtn.dataset.action) {
        case "inc":
          qtyEl.textContent = String(clamp(Number(qtyEl.textContent) + 1, 1, 99));
          break;
        case "dec":
          qtyEl.textContent = String(clamp(Number(qtyEl.textContent) - 1, 1, 99));
          break;
        case "add-cart": {
          const qty = Number(qtyEl.textContent) || 1;
          Cart.add(product.id, qty);
          qtyEl.textContent = "1";
          renderCart();
          openAddedCartModal(product.id);
          break;
        }
        case "enquire": {
          const qty = Number(qtyEl.textContent) || 1;
          openEnquiryModal(product.id, qty);
          break;
        }
      }
    });

    const searchInput = qs("#productSearch");
    if (searchInput) {
      const doFilter = debounce(() => {
        const term = searchInput.value.trim().toLowerCase();
        const filtered = term
          ? PRODUCTS.filter(
              (p) => p.name.toLowerCase().includes(term) || p.description.toLowerCase().includes(term)
            )
          : PRODUCTS;
        renderProducts(filtered);
      }, 150);
      searchInput.addEventListener("input", doFilter);
    }

    initVoiceButton(qs("#voiceSearchBtn"), (text) => {
      if (searchInput) {
        searchInput.value = text;
        searchInput.dispatchEvent(new Event("input"));
      }
    });
  }

  /* ============================== Voice input (Web Speech API) ============================== */

  function initVoiceButton(button, onResult) {
    if (!button) return;
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      button.hidden = true;
      return;
    }

    let recognition = null;
    let listening = false;

    button.addEventListener("click", () => {
      if (listening) {
        recognition && recognition.stop();
        return;
      }
      recognition = new SpeechRecognition();
      recognition.lang = "en-IN";
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        listening = true;
        button.classList.add("is-listening");
      };
      recognition.onend = () => {
        listening = false;
        button.classList.remove("is-listening");
      };
      recognition.onerror = () => {
        listening = false;
        button.classList.remove("is-listening");
        showToast("Couldn't hear that - please try again or type instead");
      };
      recognition.onresult = (event) => {
        const text = event.results?.[0]?.[0]?.transcript || "";
        if (text) onResult(text);
      };

      try {
        recognition.start();
      } catch (err) {
        showToast("Voice search is unavailable right now");
      }
    });
  }

  /* ============================== Cart panel ============================== */

  function ensureCartBackdrop() {
    let backdrop = qs("#cartBackdrop");
    if (!backdrop) {
      backdrop = document.createElement("div");
      backdrop.id = "cartBackdrop";
      backdrop.className = "cart-backdrop";
      document.body.appendChild(backdrop);
      backdrop.addEventListener("click", closeCart);
    }
    return backdrop;
  }

  function cartItemHtml(line) {
    return `
      <div class="cart-item" data-id="${line.id}">
        <img src="${encodeURI(line.product.image)}" alt="${escapeHtml(line.product.name)}" loading="lazy" decoding="async" />
        <div class="cart-item-info">
          <p class="cart-item-name">${escapeHtml(line.product.name)}</p>
          <p class="cart-item-price">${formatINR(line.product.price)} each</p>
          <div class="cart-item-row">
            <div class="cart-item-qty" role="group" aria-label="Quantity">
              <button type="button" data-action="dec" aria-label="Decrease quantity">&minus;</button>
              <span>${line.qty}</span>
              <button type="button" data-action="inc" aria-label="Increase quantity">+</button>
            </div>
            <span class="cart-item-price">${formatINR(line.lineTotal)}</span>
          </div>
        </div>
        <button type="button" class="cart-item-remove" data-action="remove" aria-label="Remove ${escapeHtml(line.product.name)} from cart">
          <i class="fas fa-trash-can" aria-hidden="true"></i>
        </button>
      </div>`;
  }

  function renderCart() {
    const badge = qs("#cartBadge");
    const count = Cart.count();
    if (badge) {
      badge.textContent = String(count);
      badge.classList.toggle("is-hidden", count === 0);
    }

    const list = qs("#cartItemsList");
    const footer = qs("#cartFooter");
    if (!list) return;

    const lines = Cart.lines();
    if (!lines.length) {
      list.innerHTML = `
        <div class="cart-empty-msg">
          <i class="fas fa-shopping-cart text-3xl mb-3 block opacity-30" aria-hidden="true"></i>Your cart is empty
        </div>`;
      if (footer) footer.classList.add("is-hidden");
      return;
    }

    list.innerHTML = lines.map(cartItemHtml).join("");
    qsa("img", list).forEach(withImgFallback);
    if (footer) footer.classList.remove("is-hidden");
    const totalEl = qs("#cartTotal");
    if (totalEl) totalEl.textContent = formatINR(Cart.total());
  }

  let lastFocusedBeforeOverlay = null;

  function openCart() {
    lastFocusedBeforeOverlay = document.activeElement;
    ensureCartBackdrop().classList.add("is-open");
    const panel = qs("#cartPanel");
    panel.classList.remove("hidden");
    requestAnimationFrame(() => panel.classList.add("is-open"));
    qs(".cart-icon-btn")?.setAttribute("aria-expanded", "true");
  }

  function closeCart() {
    const panel = qs("#cartPanel");
    const backdrop = qs("#cartBackdrop");
    panel.classList.remove("is-open");
    backdrop?.classList.remove("is-open");
    qs(".cart-icon-btn")?.setAttribute("aria-expanded", "false");
    setTimeout(() => panel.classList.add("hidden"), 250);
    if (lastFocusedBeforeOverlay) lastFocusedBeforeOverlay.focus?.();
  }

  function toggleCart() {
    const panel = qs("#cartPanel");
    if (panel.classList.contains("is-open")) closeCart();
    else openCart();
  }

  function initCartPanel() {
    renderCart();

    qs(".cart-icon-btn")?.addEventListener("click", toggleCart);
    qs("#cartPanel .cart-panel-header button")?.addEventListener("click", closeCart);
    qs("#cartClearBtn")?.addEventListener("click", () => {
      Cart.clear();
      renderCart();
    });
    qs("#cartGpayBtn")?.addEventListener("click", openCartEnquiry);

    qs("#cartItemsList")?.addEventListener("click", (e) => {
      const itemEl = e.target.closest(".cart-item");
      if (!itemEl) return;
      const id = itemEl.dataset.id;
      const line = Cart.lines().find((l) => l.id === id);
      if (!line) return;
      const actionBtn = e.target.closest("[data-action]");
      if (!actionBtn) return;

      if (actionBtn.dataset.action === "inc") {
        Cart.setQty(id, line.qty + 1);
        renderCart();
      } else if (actionBtn.dataset.action === "dec") {
        if (line.qty <= 1) {
          openRemoveConfirm(id);
        } else {
          Cart.setQty(id, line.qty - 1);
          renderCart();
        }
      } else if (actionBtn.dataset.action === "remove") {
        openRemoveConfirm(id);
      }
    });
  }

  /* ============================== Added-to-cart modal ============================== */

  let addedCartProductId = null;

  function openAddedCartModal(productId) {
    addedCartProductId = productId;
    const product = productById(productId);
    if (!product) return;

    qs("#addedCartProductName").textContent = product.name;
    const img = qs("#addedCartProductImg");
    img.src = encodeURI(product.image);
    img.alt = product.name;
    withImgFallback(img);

    syncAddedCartModal();

    const modal = qs("#addedCartModal");
    modal.classList.add("is-open");
    qs(".added-cart-box", modal)?.focus();
  }

  function syncAddedCartModal() {
    const line = Cart.lines().find((l) => l.id === addedCartProductId);
    qs("#addedCartQtyValue").value = line ? String(line.qty) : "1";
    qs("#addedCartItemsCount").textContent = `${Cart.count()} item${Cart.count() === 1 ? "" : "s"}`;
    qs("#addedCartSubtotal").textContent = formatINR(Cart.total());
  }

  function closeAddedCartModal() {
    qs("#addedCartModal").classList.remove("is-open");
  }

  function changeAddedCartQty(delta) {
    if (!addedCartProductId) return;
    const line = Cart.lines().find((l) => l.id === addedCartProductId);
    if (!line) return;
    Cart.setQty(addedCartProductId, line.qty + delta);
    renderCart();
    syncAddedCartModal();
  }

  function viewCartFromAddedModal() {
    closeAddedCartModal();
    openCart();
  }

  function initAddedCartModal() {
    const modal = qs("#addedCartModal");
    qs(".added-cart-close-btn", modal)?.addEventListener("click", closeAddedCartModal);
    qs("#addedCartContinueBtn")?.addEventListener("click", closeAddedCartModal);
    qs(".added-cart-viewcart-btn", modal)?.addEventListener("click", viewCartFromAddedModal);
    qs("#addedCartItemsCount")?.addEventListener("click", (e) => {
      e.preventDefault();
      viewCartFromAddedModal();
    });
    qs(".added-cart-qty-ctrl", modal)?.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-step]");
      if (btn) changeAddedCartQty(Number(btn.dataset.step));
    });
    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeAddedCartModal();
    });
  }

  /* ============================== Remove-confirm modal ============================== */

  let pendingRemoveId = null;

  function openRemoveConfirm(id) {
    const product = productById(id);
    if (!product) return;
    pendingRemoveId = id;
    qs("#removeConfirmProductName").textContent = product.name;
    qs("#removeConfirmModal").classList.add("is-open");
  }

  function closeRemoveConfirmModal() {
    pendingRemoveId = null;
    qs("#removeConfirmModal").classList.remove("is-open");
  }

  function confirmRemoveFromCart() {
    if (pendingRemoveId) {
      Cart.remove(pendingRemoveId);
      renderCart();
    }
    closeRemoveConfirmModal();
  }

  function initRemoveConfirmModal() {
    const modal = qs("#removeConfirmModal");
    qs("#removeConfirmCancelBtn")?.addEventListener("click", closeRemoveConfirmModal);
    qs(".remove-confirm-ok-btn", modal)?.addEventListener("click", confirmRemoveFromCart);
    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeRemoveConfirmModal();
    });
  }

  /* ============================== Enquiry modal ============================== */

  const QTY_PRESETS = [1, 2, 5, 10, 20];
  let enquiryMode = "product"; // "product" | "cart"
  let enquiryProduct = null;
  let enquiryQty = 1;

  function renderQtyButtons(container, selected, onSelect) {
    container.innerHTML =
      QTY_PRESETS.map(
        (n) => `<button type="button" data-qty="${n}" class="${n === selected ? "is-active" : ""}">${n}</button>`
      ).join("") + `<button type="button" data-qty="custom" class="${QTY_PRESETS.includes(selected) ? "" : "is-active"}">Custom</button>`;

    container.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-qty]");
      if (!btn) return;
      if (btn.dataset.qty === "custom") {
        let existing = container.parentElement.querySelector(".enquiry-qty-custom-input");
        if (!existing) {
          existing = document.createElement("input");
          existing.type = "number";
          existing.min = "1";
          existing.max = "9999";
          existing.className = "enquiry-qty-custom-input";
          existing.placeholder = "Enter quantity";
          container.parentElement.appendChild(existing);
          existing.addEventListener("input", () => {
            const val = clamp(Number(existing.value) || 1, 1, 9999);
            onSelect(val);
          });
        }
        existing.focus();
        qsa("button", container).forEach((b) => b.classList.remove("is-active"));
        btn.classList.add("is-active");
        return;
      }
      container.parentElement.querySelector(".enquiry-qty-custom-input")?.remove();
      qsa("button", container).forEach((b) => b.classList.remove("is-active"));
      btn.classList.add("is-active");
      onSelect(Number(btn.dataset.qty));
    });
  }

  function openEnquiryModal(productId, presetQty) {
    const product = productById(productId);
    if (!product) return;

    enquiryMode = "product";
    enquiryProduct = product;
    enquiryQty = presetQty && presetQty > 0 ? presetQty : 1;

    qs("#enquiryProductView").hidden = false;
    qs("#enquiryCartView").hidden = true;

    qs("#enquiry-product-img").src = encodeURI(product.image);
    qs("#enquiry-product-img").alt = product.name;
    withImgFallback(qs("#enquiry-product-img"));
    qs("#enquiry-product-name").textContent = product.name;
    qs("#enquiry-product-rate").textContent = formatINR(product.price) + " / unit (approx.)";

    const qtyContainer = qs("#enquiry-qty-buttons");
    renderQtyButtons(qtyContainer, enquiryQty, (val) => {
      enquiryQty = val;
      qs("#enquiry-qty-value").value = String(val);
    });
    qs("#enquiry-qty-value").value = String(enquiryQty);

    qs("#enquiry-phone").value = "";
    qs("#enquiry-details").value = "";
    qs("#phone-error").classList.add("hidden");
    qs("#enquiry-phone").classList.remove("has-error");

    showEnquiryModal();
  }

  function openCartEnquiry() {
    if (!Cart.lines().length) {
      showToast("Your cart is empty");
      return;
    }
    enquiryMode = "cart";

    qs("#enquiryProductView").hidden = true;
    const cartView = qs("#enquiryCartView");
    cartView.hidden = false;

    const lines = Cart.lines();
    cartView.innerHTML = `
      <div class="enquiry-cart-list">
        ${lines
          .map(
            (l) => `
          <div class="enquiry-cart-item">
            <span>${escapeHtml(l.product.name)} &times; ${l.qty}</span>
            <span>${formatINR(l.lineTotal)}</span>
          </div>`
          )
          .join("")}
      </div>
      <div class="enquiry-cart-total">
        <span>Grand Total</span><span>${formatINR(Cart.total())}</span>
      </div>
      <div class="enquiry-field-wrap">
        <label class="text-xs font-bold text-gray-600 uppercase" for="enquiry-cart-details">Workshop Name &amp; Address</label>
        <textarea id="enquiry-cart-details" class="enquiry-textarea" rows="2" placeholder="Any specific requirements..."></textarea>
      </div>
      <div class="enquiry-field-wrap">
        <label class="text-xs font-bold text-gray-600 uppercase" for="enquiry-cart-phone">Your Phone Number *</label>
        <input type="tel" id="enquiry-cart-phone" class="enquiry-input" maxlength="10" inputmode="numeric" placeholder="9876543210" />
        <p id="cart-phone-error" class="text-red-500 text-xs hidden mt-1" role="alert">Enter valid 10-digit number</p>
      </div>
      <button type="button" class="enquiry-submit-btn" id="enquiryCartSubmitBtn">
        <i class="fab fa-whatsapp" aria-hidden="true"></i> Send Order via WhatsApp
      </button>
      <p class="text-center text-xs text-gray-400 mt-3">We'll confirm your order and share GPay/UPI payment details on WhatsApp.</p>
    `;

    qs("#enquiryCartSubmitBtn").addEventListener("click", submitCartEnquiry);

    showEnquiryModal();
  }

  function showEnquiryModal() {
    lastFocusedBeforeOverlay = document.activeElement;
    const modal = qs("#enquiryModal");
    modal.classList.add("is-open");
    qs(".enquiry-modal-box", modal)?.focus();
  }

  function closeEnquiryModal() {
    qs("#enquiryModal").classList.remove("is-open");
    if (lastFocusedBeforeOverlay) lastFocusedBeforeOverlay.focus?.();
  }

  const PHONE_RE = /^[6-9]\d{9}$/;

  function submitEnquiry() {
    const phoneInput = qs("#enquiry-phone");
    const phone = phoneInput.value.trim();
    if (!PHONE_RE.test(phone)) {
      qs("#phone-error").classList.remove("hidden");
      phoneInput.classList.add("has-error");
      phoneInput.focus();
      return;
    }
    qs("#phone-error").classList.add("hidden");
    phoneInput.classList.remove("has-error");

    const details = qs("#enquiry-details").value.trim();
    const lines = [
      "Hi Swapnil Chemicals, I would like to enquire about:",
      "",
      `${enquiryProduct.name} (approx. ${formatINR(enquiryProduct.price)}/unit)`,
      `Quantity: ${enquiryQty}`,
    ];
    if (details) lines.push(`Details: ${details}`);
    lines.push(`My phone number: ${phone}`, "", "Please share final pricing and availability. Thank you!");

    window.open(waLink(lines.join("\n")), "_blank", "noopener");
    closeEnquiryModal();
  }

  function submitCartEnquiry() {
    const phoneInput = qs("#enquiry-cart-phone");
    const phone = phoneInput.value.trim();
    if (!PHONE_RE.test(phone)) {
      qs("#cart-phone-error").classList.remove("hidden");
      phoneInput.classList.add("has-error");
      phoneInput.focus();
      return;
    }
    qs("#cart-phone-error").classList.add("hidden");
    phoneInput.classList.remove("has-error");

    const details = qs("#enquiry-cart-details")?.value.trim();
    const lines = ["Hi Swapnil Chemicals, I'd like to place this order:", ""];
    Cart.lines().forEach((l) => {
      lines.push(`- ${l.product.name} x${l.qty} = ${formatINR(l.lineTotal)}`);
    });
    lines.push("", `Grand Total: ${formatINR(Cart.total())}`);
    if (details) lines.push(`Details: ${details}`);
    lines.push(`My phone number: ${phone}`, "", "I'll complete payment via GPay/UPI once confirmed. Thank you!");

    window.open(waLink(lines.join("\n")), "_blank", "noopener");
    closeEnquiryModal();
  }

  function initEnquiryModal() {
    const modal = qs("#enquiryModal");
    qs(".enquiry-close-btn", modal)?.addEventListener("click", closeEnquiryModal);
    qs(".enquiry-submit-btn", qs("#enquiryProductView"))?.addEventListener("click", submitEnquiry);
    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeEnquiryModal();
    });

    const phoneInput = qs("#enquiry-phone");
    phoneInput?.addEventListener("input", () => {
      phoneInput.value = phoneInput.value.replace(/\D/g, "").slice(0, 10);
    });
  }

  /* ============================== Global overlay behaviour ============================== */

  function initGlobalOverlayBehaviour() {
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      if (qs("#enquiryModal")?.classList.contains("is-open")) return closeEnquiryModal();
      if (qs("#addedCartModal")?.classList.contains("is-open")) return closeAddedCartModal();
      if (qs("#removeConfirmModal")?.classList.contains("is-open")) return closeRemoveConfirmModal();
      if (qs("#assistantPanel") && !qs("#assistantPanel").classList.contains("hidden")) return closeAssistant();
      if (qs("#cartPanel")?.classList.contains("is-open")) return closeCart();
    });
  }

  /* ============================== AI assistant (rule-based, on-device) ============================== */
  /*
   * No LLM API key is called from the browser (that would leak credentials
   * from a static site). Instead this is a small, transparent keyword
   * matcher over the same facts published in the page's FAQ/JSON-LD.
   */

  const QUICK_REPLIES = ["Products", "Pricing", "Bulk orders", "Payment methods", "Contact us"];

  const KNOWLEDGE = [
    {
      keywords: ["bulk", "wholesale", "retail"],
      reply:
        "We supply both bulk and retail quantities. For wholesale pricing call 9352470085 or 9024598298, or tap Enquiry on any product.",
    },
    {
      keywords: ["payment", "pay", "upi", "gpay", "google pay"],
      reply:
        "We accept UPI and Google Pay - scan the QR code or pay to the UPI ID in the Contact section. Call us to arrange other payment methods.",
    },
    {
      keywords: ["gst", "msme", "udyam", "registered", "registration", "certificate", "legal"],
      reply:
        "Yes, we're a registered business: GST 08CIJPS1734A1ZE, MSME/2020/6194, and Udyam UDYAM-RJ-17-0022468.",
    },
    {
      keywords: ["order", "how do i", "how to buy", "place"],
      reply:
        'Pick a product, choose a quantity, then tap "Add to Cart" or "Enquiry" - your request goes straight to us on WhatsApp, no account needed.',
    },
    {
      keywords: ["location", "address", "where", "based", "jaipur"],
      reply: "We're based in Jaipur, Rajasthan, and ship to bulk and retail customers across India.",
    },
    {
      keywords: ["custom", "packaging", "quantity"],
      reply:
        "For requirements outside the listed options, call or WhatsApp us directly and we'll work it out with you.",
    },
    {
      keywords: ["contact", "phone", "number", "call", "email"],
      reply: "Call us at 9352470085 or 9024598298, or email swapnilchemicals10@gmail.com - we're happy to help.",
    },
    {
      keywords: ["hi", "hello", "hey", "namaste"],
      reply: "Hello! I'm the Swapnil Chemicals assistant. Ask me about products, pricing, bulk orders or payment.",
    },
    {
      keywords: ["thank", "thanks", "thank you"],
      reply: "You're welcome! Let us know if there's anything else you need.",
    },
  ];

  function findProductMention(text) {
    return PRODUCTS.find((p) => text.includes(p.name.toLowerCase()));
  }

  function getAssistantReply(rawText) {
    const text = rawText.toLowerCase();

    const product = findProductMention(text);
    if (product) {
      return `${product.name} is priced at ${formatINR(product.price)} (approx.). ${product.description}. Tap the product card under "Our Premium Products" to add it to your cart or send an enquiry.`;
    }

    if (/price|cost|rate/.test(text)) {
      return "Prices range from about ₹70 (Car Foaming Wash, Glass Cleaner, Micro Towel) up to ₹2000 (Foaming Gun). Open the Products section for the full list, or tell me a product name for its exact price.";
    }

    if (/product|catalog|range|what do you (sell|make|have)/.test(text)) {
      return `We manufacture: ${PRODUCTS.map((p) => p.name).filter((v, i, a) => a.indexOf(v) === i).join(", ")}. Scroll to "Our Premium Products" to see all of them with prices.`;
    }

    for (const entry of KNOWLEDGE) {
      if (entry.keywords.some((k) => text.includes(k))) {
        return entry.reply;
      }
    }

    return "I'm not sure about that one - for anything specific, please call 9352470085 / 9024598298 or use the Enquiry button and we'll get back to you personally.";
  }

  function appendAssistantMessage(role, text) {
    const container = qs("#assistantMessages");
    const bubble = document.createElement("div");
    bubble.className = `assistant-msg ${role}`;
    bubble.textContent = text;
    container.appendChild(bubble);
    container.scrollTop = container.scrollHeight;
    return bubble;
  }

  function showAssistantTyping() {
    const container = qs("#assistantMessages");
    const bubble = document.createElement("div");
    bubble.className = "assistant-msg bot typing";
    bubble.innerHTML = "<span></span><span></span><span></span>";
    container.appendChild(bubble);
    container.scrollTop = container.scrollHeight;
    return bubble;
  }

  function sendAssistantMessage(text) {
    const trimmed = text.trim();
    if (!trimmed) return;
    appendAssistantMessage("user", trimmed);

    const typingBubble = showAssistantTyping();
    const delay = 350 + Math.random() * 350;
    setTimeout(() => {
      typingBubble.remove();
      appendAssistantMessage("bot", getAssistantReply(trimmed));
    }, delay);
  }

  function renderQuickReplies() {
    const container = qs("#assistantQuickReplies");
    if (!container) return;
    container.innerHTML = QUICK_REPLIES.map((label) => `<button type="button" class="quick-reply-btn">${escapeHtml(label)}</button>`).join("");
    container.addEventListener("click", (e) => {
      const btn = e.target.closest(".quick-reply-btn");
      if (btn) sendAssistantMessage(btn.textContent);
    });
  }

  let assistantGreeted = false;

  function openAssistant() {
    lastFocusedBeforeOverlay = document.activeElement;
    qs("#assistantPanel").classList.remove("hidden");
    qs("#aiAssistantBtn")?.setAttribute("aria-expanded", "true");
    if (!assistantGreeted) {
      appendAssistantMessage(
        "bot",
        "Hi! I'm the Swapnil Chemicals assistant. Ask about products, pricing, bulk orders, payment or delivery - or tap a quick reply below."
      );
      assistantGreeted = true;
    }
    qs("#assistantInput")?.focus();
  }

  function closeAssistant() {
    qs("#assistantPanel").classList.add("hidden");
    qs("#aiAssistantBtn")?.setAttribute("aria-expanded", "false");
    if (lastFocusedBeforeOverlay) lastFocusedBeforeOverlay.focus?.();
  }

  function toggleAssistant() {
    const panel = qs("#assistantPanel");
    if (panel.classList.contains("hidden")) openAssistant();
    else closeAssistant();
  }

  function initAssistant() {
    renderQuickReplies();
    qs("#aiAssistantBtn")?.addEventListener("click", toggleAssistant);
    qs(".assistant-panel-header button")?.addEventListener("click", closeAssistant);

    const form = qs("#assistantForm");
    const input = qs("#assistantInput");
    form?.addEventListener("submit", (e) => {
      e.preventDefault();
      if (!input.value.trim()) return;
      sendAssistantMessage(input.value);
      input.value = "";
    });

    initVoiceButton(qs("#voiceAssistantBtn"), (text) => {
      input.value = text;
      sendAssistantMessage(text);
      input.value = "";
    });
  }

  /* ============================== Init ============================== */

  document.addEventListener("DOMContentLoaded", () => {
    Cart.load();

    initScrollChrome();
    initCopyButtons();
    initProductsGrid();
    initCartPanel();
    initAddedCartModal();
    initRemoveConfirmModal();
    initEnquiryModal();
    initAssistant();
    initGlobalOverlayBehaviour();

    renderCart();
  });
})();
