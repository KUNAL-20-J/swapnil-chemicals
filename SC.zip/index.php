<!doctype html>
<!-- Automobile new code 04-09-26 -->
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Swapnil Chemicals | Automobile Cleaning Products Manufacturer, Jaipur</title>
        <link rel="icon" type="image/jpeg" href="SC%20Logo.jpg" />
        <link rel="apple-touch-icon" href="SC%20Logo.jpg" />
        <link rel="manifest" href="manifest.webmanifest" />
        <meta
            name="description"
            content="Swapnil Chemicals - Leading manufacturers of automobile cleaning products in Jaipur. Bulk & retail. Dashboard polish, tyre polish, car wash & more."
        />
        <meta
            name="keywords"
            content="automobile cleaning, car cleaning, dashboard polish, tyre polish, car wash, glass cleaner, Jaipur manufacturer"
        />
        <meta name="robots" content="index, follow" />
        <meta name="color-scheme" content="light" />
        <meta name="theme-color" content="#1e293b" />
        <meta name="referrer" content="strict-origin-when-cross-origin" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="Swapnil Chemicals" />

        <!--
            TODO before going live: add <link rel="canonical" href="https://<your-domain>/" />,
            an <meta property="og:url"> tag, and switch og:image/twitter:image to absolute URLs
            (https://<your-domain>/SC%20Logo.jpg) once the production domain is known.
        -->
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="Swapnil Chemicals" />
        <meta property="og:title" content="Swapnil Chemicals | Automobile Cleaning Products Manufacturer, Jaipur" />
        <meta
            property="og:description"
            content="Manufacturers of premium automobile cleaning products in Jaipur - dashboard polish, tyre polish, car wash, glass cleaner & more. Bulk & retail."
        />
        <meta property="og:image" content="SC%20Logo.jpg" />
        <meta property="og:locale" content="en_IN" />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:title" content="Swapnil Chemicals | Automobile Cleaning Products Manufacturer, Jaipur" />
        <meta
            name="twitter:description"
            content="Manufacturers of premium automobile cleaning products in Jaipur - dashboard polish, tyre polish, car wash, glass cleaner & more."
        />
        <meta name="twitter:image" content="SC%20Logo.jpg" />

        <meta
            http-equiv="Content-Security-Policy"
            content="default-src 'self'; script-src 'self' https://cdn.tailwindcss.com; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com; font-src https://fonts.gstatic.com https://cdnjs.cloudflare.com; img-src 'self' data: https://www.gstatic.com https://api.qrserver.com; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self';"
        />

        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
        <script src="https://cdn.tailwindcss.com"></script>
        <link
            href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap"
            rel="stylesheet"
        />
        <link rel="stylesheet" href="styles.css" />
        <script type="application/ld+json">
            {
                "@context": "https://schema.org",
                "@type": "LocalBusiness",
                "name": "Swapnil Chemicals",
                "description": "Manufacturers and marketers of automobile cleaning products - dashboard polish, tyre polish, car wash, glass cleaner and more.",
                "image": "SC%20Logo.jpg",
                "telephone": ["+919352470085", "+919024598298"],
                "email": "swapnilchemicals10@gmail.com",
                "address": {
                    "@type": "PostalAddress",
                    "addressLocality": "Jaipur",
                    "addressRegion": "Rajasthan",
                    "addressCountry": "IN"
                },
                "founder": {
                    "@type": "Person",
                    "name": "Gajendra Jain"
                }
            }
        </script>
        <script type="application/ld+json">
            {
                "@context": "https://schema.org",
                "@type": "FAQPage",
                "mainEntity": [
                    {
                        "@type": "Question",
                        "name": "Do you supply bulk or only retail orders?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "Yes, Swapnil Chemicals supplies both bulk and retail quantities. For wholesale pricing, call 9352470085 or 9024598298, or use the Enquiry button on any product."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "What payment methods do you accept?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "We accept UPI and Google Pay - scan the QR code or pay to the UPI ID shown in the Contact section. Call us to discuss other payment arrangements."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "Is Swapnil Chemicals a registered business?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "Yes. We are GST registered (08CIJPS1734A1ZE), MSME certified (MSME/2020/6194), and Udyam registered (UDYAM-RJ-17-0022468)."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "How do I place an order?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "Pick a product, choose a quantity, and tap Add to Cart or Enquiry. Your request is sent directly to us on WhatsApp - no account or login needed."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "Where is Swapnil Chemicals based?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "We are based in Jaipur, Rajasthan, and support both bulk and retail customers."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "Do you offer custom quantities or packaging?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "For requirements outside the listed options, contact us directly by phone or WhatsApp and we will get back to you."
                        }
                    }
                ]
            }
        </script>
        <script type="application/ld+json">
            {
                "@context": "https://schema.org",
                "@graph": [
                    {
                        "@type": "Product",
                        "name": "Dashboard Polish",
                        "image": "Dashboard%20Polish.jpeg",
                        "description": "Premium dashboard polish for long-lasting shine",
                        "brand": { "@type": "Brand", "name": "Swapnil Chemicals" },
                        "offers": { "@type": "Offer", "price": "200", "priceCurrency": "INR", "url": "#products" }
                    },
                    {
                        "@type": "Product",
                        "name": "Tyre Polish",
                        "image": "Tyre%20Polish.jpeg",
                        "description": "High-gloss tyre polish for enhanced appearance",
                        "brand": { "@type": "Brand", "name": "Swapnil Chemicals" },
                        "offers": { "@type": "Offer", "price": "150", "priceCurrency": "INR", "url": "#products" }
                    },
                    {
                        "@type": "Product",
                        "name": "Car Foaming Wash",
                        "image": "Car%20Foaming%20Wash.jpeg",
                        "description": "Advanced foaming wash for thorough cleaning",
                        "brand": { "@type": "Brand", "name": "Swapnil Chemicals" },
                        "offers": { "@type": "Offer", "price": "70", "priceCurrency": "INR", "url": "#products" }
                    },
                    {
                        "@type": "Product",
                        "name": "Glass Cleaner",
                        "image": "Glass%20Cleaner.jpeg",
                        "description": "Streak-free glass cleaner for crystal clear visibility",
                        "brand": { "@type": "Brand", "name": "Swapnil Chemicals" },
                        "offers": { "@type": "Offer", "price": "70", "priceCurrency": "INR", "url": "#products" }
                    },
                    {
                        "@type": "Product",
                        "name": "Interior Cleaner",
                        "image": "Interior%20Cleaner.png",
                        "description": "Effective interior cleaner for all surfaces",
                        "brand": { "@type": "Brand", "name": "Swapnil Chemicals" },
                        "offers": { "@type": "Offer", "price": "130", "priceCurrency": "INR", "url": "#products" }
                    },
                    {
                        "@type": "Product",
                        "name": "Foaming Gun",
                        "image": "Foaming%20Gun.jpeg",
                        "description": "Professional foaming gun for car wash",
                        "brand": { "@type": "Brand", "name": "Swapnil Chemicals" },
                        "offers": { "@type": "Offer", "price": "2000", "priceCurrency": "INR", "url": "#products" }
                    },
                    {
                        "@type": "Product",
                        "name": "Micro Towel",
                        "image": "Micro%20Towel.jpg",
                        "description": "Ultra soft Micro Towel",
                        "brand": { "@type": "Brand", "name": "Swapnil Chemicals" },
                        "offers": { "@type": "Offer", "price": "70", "priceCurrency": "INR", "url": "#products" }
                    },
                    {
                        "@type": "Product",
                        "name": "Micro Towel",
                        "image": "Micro%20Towel%202.jpg",
                        "description": "Ultra soft Micro Towel",
                        "brand": { "@type": "Brand", "name": "Swapnil Chemicals" },
                        "offers": { "@type": "Offer", "price": "110", "priceCurrency": "INR", "url": "#products" }
                    },
                    {
                        "@type": "Product",
                        "name": "Micro Towel",
                        "image": "Micro%20Towel%203.jpg",
                        "description": "Ultra soft Micro Towel",
                        "brand": { "@type": "Brand", "name": "Swapnil Chemicals" },
                        "offers": { "@type": "Offer", "price": "130", "priceCurrency": "INR", "url": "#products" }
                    }
                ]
            }
        </script>
    </head>

    <body class="min-h-screen bg-slate-50 text-gray-800">
        <a href="#main-content" class="skip-link">Skip to main content</a>
        <div class="scroll-progress" id="scrollProgress"></div>

        <noscript>
            <div class="noscript-banner">
                This site needs JavaScript to show products, pricing and the enquiry form. Please enable it, or call us
                directly at
                <a href="tel:9352470085">9352470085</a> /
                <a href="tel:9024598298">9024598298</a>.
            </div>
        </noscript>

        <header class="sticky top-0 z-50 nav-blur">
            <div class="container mx-auto px-4 py-4">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <div class="flex items-center space-x-4 mb-4 md:mb-0">
                        <div class="relative">
                            <div
                                class="w-14 h-14 rounded-full flex items-center justify-center overflow-hidden ring-2 ring-blue-500/20"
                            >
                                <img
                                    src="SC%20Logo.jpg"
                                    alt="Swapnil Chemicals logo"
                                    class="w-full h-full object-cover"
                                    width="56"
                                    height="56"
                                    decoding="async"
                                />
                            </div>
                            <div class="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full pulse-ring"></div>
                        </div>
                        <div>
                            <h1 class="text-2xl font-bold gradient-text">Swapnil Chemicals</h1>
                            <p class="text-sm text-gray-600">
                                Manufacturers & marketers of automobile cleaning products
                            </p>
                        </div>
                    </div>

                    <div class="flex items-center gap-3">
                        <div class="glass-card px-4 py-2 rounded-lg">
                            <p class="text-gray-700 font-medium">
                                <i class="fas fa-map-marker-alt text-blue-600 mr-2" aria-hidden="true"></i>Jaipur • Bulk & Retail
                            </p>
                        </div>
                        <button type="button" class="cart-icon-btn" aria-label="Open cart" aria-expanded="false">
                            <i class="fas fa-shopping-cart text-base" aria-hidden="true"></i>
                            <span class="cart-badge is-hidden" id="cartBadge" aria-live="polite">0</span>
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <main id="main-content" tabindex="-1">
            <section class="hero-gradient text-white min-h-[86.5vh] flex flex-col relative">
                <div class="hero-band-top flex-1 flex items-start relative z-10 pt-16 md:pt-24 pb-6">
                    <div class="container mx-auto px-4">
                        <div class="max-w-5xl mx-auto text-center hero-content-in">
                            <h2 class="text-4xl md:text-6xl font-bold leading-tight">
                                Premium Automobile <br /><span class="text-blue-400">Cleaning Solutions</span>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="hero-band-bottom flex-1 flex items-start relative z-10 pt-6 pb-10">
                    <div class="container mx-auto px-4">
                        <div class="max-w-5xl mx-auto text-center">
                            <p class="text-lg md:text-xl mb-10 opacity-90 max-w-3xl mx-auto leading-relaxed">
    Swapnil Chemicals is a Jaipur-based manufacturer of Premium Automobile Cleaning
    Products, trusted by bulk and retail customers since 2020. We produce our own
    Dashboard Polish, Tyre Polish, Car Foaming Wash, Glass Cleaner and more, ensuring
    consistent quality. As a GST registered, MSME and Udyam certified business, we
    supply orders across India. Call us at 9352470085 or 9024598298 for bulk orders
    or pricing.
</p>
                            <div class="flex flex-wrap justify-center gap-6">
                                <a
                                    href="#products"
                                    class="btn-primary text-white px-10 py-4 rounded-xl font-semibold text-lg"
                                    ><i class="fas fa-boxes mr-3" aria-hidden="true"></i>View Products</a
                                ><a
                                    href="#contact"
                                    class="btn-secondary text-white px-10 py-4 rounded-xl font-semibold text-lg"
                                    ><i class="fas fa-phone-alt fa-flip-horizontal mr-3" aria-hidden="true"></i>Contact Now</a
                                >
                            </div>
                        </div>
                    </div>
                </div>
                <div class="absolute top-20 left-10 w-20 h-20 bg-blue-500/10 rounded-full blur-xl ambient-blob"></div>
                <div
                    class="absolute bottom-20 right-10 w-32 h-32 bg-purple-500/10 rounded-full blur-xl ambient-blob delay-4"
                ></div>
                <div
                    class="absolute top-1/2 right-1/4 w-24 h-24 bg-cyan-400/10 rounded-full blur-xl ambient-blob delay-2"
                ></div>
            </section>

            <section id="business-details" class="pt-6 pb-0 relative">
                <div class="container mx-auto px-4">
                    <div class="text-center mb-6 mt-8">
                        <h2 class="text-4xl font-bold gradient-text mb-4">Business Details</h2>
                        <div class="section-divider max-w-xs mx-auto"></div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
                        <div class="feature-card p-8 rounded-2xl">
                            <div class="flex items-center mb-6">
                                <div
                                    class="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mr-6 shadow-lg"
                                >
                                    <i class="fas fa-user-tie text-white text-2xl"></i>
                                </div>
                                <div>
                                    <p class="text-2xl font-bold text-gray-800">Gajendra Jain</p>
                                </div>
                            </div>
                        </div>
                        <div class="feature-card p-8 rounded-2xl">
                            <div class="flex items-center mb-6">
                                <div
                                    class="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mr-6 shadow-lg"
                                >
                                    <i class="fas fa-phone-alt icon-rotate-270 text-white text-2xl" aria-hidden="true"></i>
                                </div>
                                <div>
                                    <h3 class="text-sm font-medium text-gray-600 uppercase tracking-wide">Phone</h3>
                                    <p class="text-lg font-bold">
                                        <a href="tel:9352470085" class="text-blue-600 block">9352470085</a
                                        ><a href="tel:9024598298" class="text-blue-600 block">9024598298</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="feature-card p-8 rounded-2xl">
                            <div class="flex items-center mb-6">
                                <div
                                    class="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mr-6 shadow-lg"
                                >
                                    <i class="fas fa-file-invoice-dollar text-white text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-sm font-medium text-gray-600 uppercase tracking-wide">
                                        GST Number
                                    </h3>
                                    <p class="text-lg font-bold text-gray-800 font-mono flex items-center gap-2">
                                        08CIJPS1734A1ZE<button
                                            type="button"
                                            class="text-gray-400 hover:text-blue-600"
                                            data-copy="08CIJPS1734A1ZE"
                                            aria-label="Copy GST number"
                                        >
                                            <i class="fas fa-copy text-sm"></i>
                                        </button>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="feature-card p-8 rounded-2xl">
                            <div class="flex items-center mb-6">
                                <div
                                    class="w-16 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center mr-6 shadow-lg"
                                >
                                    <i class="fas fa-envelope text-white text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-sm font-medium text-gray-600 uppercase tracking-wide">Email</h3>
                                    <a href="mailto:swapnilchemicals10@gmail.com" class="text-blue-600 break-all"
                                        >swapnilchemicals10@gmail.com</a
                                    >
                                </div>
                            </div>
                        </div>
                        <div class="feature-card p-8 rounded-2xl">
                            <div class="flex items-center mb-6">
                                <div
                                    class="w-16 h-16 bg-gradient-to-br from-amber-500 to-yellow-600 rounded-2xl flex items-center justify-center mr-6 shadow-lg"
                                >
                                    <i class="fas fa-award text-white text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-sm font-medium text-gray-600 uppercase tracking-wide">MSME</h3>
                                    <p class="text-lg font-bold text-gray-800 font-mono">MSME/2020/6194</p>
                                </div>
                            </div>
                        </div>
                        <div class="feature-card p-8 rounded-2xl">
                            <div class="flex items-center mb-6">
                                <div
                                    class="w-16 h-16 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-2xl flex items-center justify-center mr-6 shadow-lg"
                                >
                                    <i class="fas fa-certificate text-white text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-sm font-medium text-gray-600 uppercase tracking-wide">Udyam</h3>
                                    <p class="text-lg font-bold text-gray-800 font-mono">UDYAM-RJ-17-0022468</p>
                                </div>
                            </div>
                        </div>
                        <div class="feature-card p-8 rounded-2xl">
                            <div class="flex items-center mb-6">
                                <div
                                    class="w-16 h-16 bg-gradient-to-br from-teal-500 to-teal-600 rounded-2xl flex items-center justify-center mr-6 shadow-lg"
                                >
                                    <i class="fas fa-building text-white text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-sm font-medium text-gray-600 uppercase tracking-wide">BRN</h3>
                                    <p class="text-lg font-bold text-gray-800 font-mono">8005220072000968</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id="products" class="pt-2 pb-8 relative">
                <div class="container mx-auto px-4">
                    <div class="text-center mb-8">
                        <h2 class="text-4xl font-bold gradient-text mb-4">Our Premium Products</h2>
                        <p class="text-xl text-gray-600 max-w-2xl mx-auto">
                            Discover our range of high-quality automobile cleaning solutions designed for professional
                            results.
                        </p>
                        <div class="section-divider max-w-xs mx-auto"></div>
                    </div>
                    <div class="max-w-xl mx-auto mb-8">
                        <div class="relative">
                            <i
                                class="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"
                                aria-hidden="true"
                            ></i>
                            <input
                                type="search"
                                id="productSearch"
                                class="w-full pl-11 pr-12 py-3 rounded-xl border border-gray-200 bg-white focus:border-blue-500 focus:outline-none focus:shadow-[0_0_0_4px_rgba(139,92,246,0.15)] transition-shadow text-sm"
                                placeholder="Search products (e.g. tyre polish, micro towel)..."
                                aria-label="Search products"
                            />
                            <button type="button" id="voiceSearchBtn" class="voice-btn" aria-label="Search by voice">
                                <i class="fas fa-microphone"></i>
                            </button>
                        </div>
                    </div>
                    <div
                        class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
                        id="productsGrid"
                    ></div>
                </div>
            </section>

            <section id="faq" class="py-8 relative">
                <div class="container mx-auto px-4">
                    <div class="text-center mb-8">
                        <h2 class="text-4xl font-bold gradient-text mb-4">Frequently Asked Questions</h2>
                        <p class="text-xl text-gray-600 max-w-2xl mx-auto">
                            Quick answers about ordering, payment and our products.
                        </p>
                        <div class="section-divider max-w-xs mx-auto"></div>
                    </div>
                    <div class="max-w-3xl mx-auto space-y-4">
                        <details
                            name="faq"
                            class="group rounded-2xl overflow-hidden border border-gray-200 bg-white shadow-sm"
                        >
                            <summary
                                class="font-semibold text-lg cursor-pointer list-none flex justify-between items-center gap-4 px-6 py-4 bg-slate-100 text-gray-800 group-open:text-white group-open:bg-gradient-to-r group-open:from-orange-500 group-open:to-orange-600 transition-colors"
                            >
                                Do you supply bulk or only retail orders?
                                <i class="fas fa-plus flex-shrink-0 group-open:hidden" aria-hidden="true"></i>
                                <i class="fas fa-minus flex-shrink-0 hidden group-open:inline" aria-hidden="true"></i>
                            </summary>
                            <p class="text-gray-600 px-6 py-4">
                                Yes — we supply both bulk and retail quantities. For wholesale pricing, call
                                <a href="tel:9352470085" class="text-blue-600">9352470085</a> or
                                <a href="tel:9024598298" class="text-blue-600">9024598298</a>, or use the "Enquiry"
                                button on any product.
                            </p>
                        </details>
                        <details
                            name="faq"
                            class="group rounded-2xl overflow-hidden border border-gray-200 bg-white shadow-sm"
                        >
                            <summary
                                class="font-semibold text-lg cursor-pointer list-none flex justify-between items-center gap-4 px-6 py-4 bg-slate-100 text-gray-800 group-open:text-white group-open:bg-gradient-to-r group-open:from-orange-500 group-open:to-orange-600 transition-colors"
                            >
                                What payment methods do you accept?
                                <i class="fas fa-plus flex-shrink-0 group-open:hidden" aria-hidden="true"></i>
                                <i class="fas fa-minus flex-shrink-0 hidden group-open:inline" aria-hidden="true"></i>
                            </summary>
                            <p class="text-gray-600 px-6 py-4">
                                We accept UPI and Google Pay — scan the QR code or pay to the UPI ID shown in the
                                Contact section. Call us to discuss other payment arrangements.
                            </p>
                        </details>
                        <details
                            name="faq"
                            class="group rounded-2xl overflow-hidden border border-gray-200 bg-white shadow-sm"
                        >
                            <summary
                                class="font-semibold text-lg cursor-pointer list-none flex justify-between items-center gap-4 px-6 py-4 bg-slate-100 text-gray-800 group-open:text-white group-open:bg-gradient-to-r group-open:from-orange-500 group-open:to-orange-600 transition-colors"
                            >
                                Is Swapnil Chemicals a registered business?
                                <i class="fas fa-plus flex-shrink-0 group-open:hidden" aria-hidden="true"></i>
                                <i class="fas fa-minus flex-shrink-0 hidden group-open:inline" aria-hidden="true"></i>
                            </summary>
                            <p class="text-gray-600 px-6 py-4">
                                Yes. We are GST registered (08CIJPS1734A1ZE), MSME certified (MSME/2020/6194), Udyam
                                registered (UDYAM-RJ-17-0022468), and hold other applicable business registrations and
                                certifications.
                            </p>
                        </details>
                        <details
                            name="faq"
                            class="group rounded-2xl overflow-hidden border border-gray-200 bg-white shadow-sm"
                        >
                            <summary
                                class="font-semibold text-lg cursor-pointer list-none flex justify-between items-center gap-4 px-6 py-4 bg-slate-100 text-gray-800 group-open:text-white group-open:bg-gradient-to-r group-open:from-orange-500 group-open:to-orange-600 transition-colors"
                            >
                                How do I place an order?
                                <i class="fas fa-plus flex-shrink-0 group-open:hidden" aria-hidden="true"></i>
                                <i class="fas fa-minus flex-shrink-0 hidden group-open:inline" aria-hidden="true"></i>
                            </summary>
                            <p class="text-gray-600 px-6 py-4">
                                Pick a product, choose a quantity, and tap "Add to Cart" or "Enquiry." Your request is
                                sent directly to us on WhatsApp — no account or login needed.
                            </p>
                        </details>
                        <details
                            name="faq"
                            class="group rounded-2xl overflow-hidden border border-gray-200 bg-white shadow-sm"
                        >
                            <summary
                                class="font-semibold text-lg cursor-pointer list-none flex justify-between items-center gap-4 px-6 py-4 bg-slate-100 text-gray-800 group-open:text-white group-open:bg-gradient-to-r group-open:from-orange-500 group-open:to-orange-600 transition-colors"
                            >
                                Where is Swapnil Chemicals based?
                                <i class="fas fa-plus flex-shrink-0 group-open:hidden" aria-hidden="true"></i>
                                <i class="fas fa-minus flex-shrink-0 hidden group-open:inline" aria-hidden="true"></i>
                            </summary>
                            <p class="text-gray-600 px-6 py-4">
                                We are based in Jaipur, Rajasthan, and support both bulk and retail customers.
                            </p>
                        </details>
                        <details
                            name="faq"
                            class="group rounded-2xl overflow-hidden border border-gray-200 bg-white shadow-sm"
                        >
                            <summary
                                class="font-semibold text-lg cursor-pointer list-none flex justify-between items-center gap-4 px-6 py-4 bg-slate-100 text-gray-800 group-open:text-white group-open:bg-gradient-to-r group-open:from-orange-500 group-open:to-orange-600 transition-colors"
                            >
                                Do you offer custom quantities or packaging?
                                <i class="fas fa-plus flex-shrink-0 group-open:hidden" aria-hidden="true"></i>
                                <i class="fas fa-minus flex-shrink-0 hidden group-open:inline" aria-hidden="true"></i>
                            </summary>
                            <p class="text-gray-600 px-6 py-4">
                                For requirements outside the listed options, contact us directly by phone or WhatsApp
                                and we'll get back to you.
                            </p>
                        </details>
                    </div>
                </div>
            </section>

            <section id="contact" class="py-8 relative">
                <div class="container mx-auto px-4">
                    <div class="text-center mb-8">
                        <h2 class="text-4xl font-bold gradient-text mb-4">Get In Touch</h2>
                        <p class="text-xl text-gray-600 max-w-2xl mx-auto">
                            Ready to experience premium automobile cleaning solutions? Contact us today.
                        </p>
                        <div class="section-divider max-w-xs mx-auto"></div>
                    </div>
                    <div class="max-w-6xl mx-auto">
                        <div class="grid grid-cols-1 gap-12">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <div class="glass-card p-8 rounded-2xl">
                                    <div class="flex items-center space-x-6">
                                        <div
                                            class="contact-icon w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg"
                                        >
                                            <i
                                                class="fas fa-phone-alt icon-rotate-270 text-white text-2xl"
                                                aria-hidden="true"
                                            ></i>
                                        </div>
                                        <div>
                                            <h3 class="font-semibold text-xl text-gray-800 mb-2">Phone</h3>
                                            <a href="tel:9352470085" class="text-blue-600 block">9352470085</a
                                            ><a href="tel:9024598298" class="text-blue-600 block">9024598298</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="glass-card p-8 rounded-2xl">
                                    <div class="flex items-center space-x-6">
                                        <div
                                            class="contact-icon w-16 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center shadow-lg"
                                        >
                                            <i class="fas fa-envelope text-white text-2xl"></i>
                                        </div>
                                        <div>
                                            <h3 class="font-semibold text-xl text-gray-800 mb-2">Email</h3>
                                            <a
                                                href="mailto:swapnilchemicals10@gmail.com"
                                                class="text-blue-600 break-all"
                                                >swapnilchemicals10@gmail.com</a
                                            >
                                        </div>
                                    </div>
                                </div>
                                <div class="glass-card p-8 rounded-2xl">
                                    <div class="flex items-center space-x-6">
                                        <div
                                            class="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg border"
                                        >
                                            <img
                                                src="https://www.gstatic.com/instantbuy/svg/dark_gpay.svg"
                                                width="48"
                                                alt="Google Pay"
                                                loading="lazy"
                                                decoding="async"
                                            />
                                        </div>
                                        <div>
                                            <h3 class="font-semibold text-xl text-gray-800 mb-2">Google Pay</h3>
                                            <div class="flex items-center gap-2">
                                                <a
                                                    href="upi://pay?pa=boism-9352470085@boi&amp;pn=Swapnil%20Chemicals&amp;cu=INR"
                                                    class="text-blue-600"
                                                    >Pay to 9352470085</a
                                                >
                                                <button
                                                    type="button"
                                                    class="text-gray-400 hover:text-blue-600"
                                                    data-copy="boism-9352470085@boi"
                                                    aria-label="Copy UPI ID"
                                                >
                                                    <i class="fas fa-copy text-sm"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-6 flex flex-col items-center">
                                        <div class="bg-white p-3 rounded-xl shadow-md">
                                            <img
                                                src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&amp;data=upi://pay?pa=boism-9352470085@boi%26pn=Swapnil%20Chemicals%26cu=INR"
                                                width="75"
                                                height="75"
                                                class="rounded-lg"
                                                alt="UPI QR"
                                                loading="lazy"
                                                decoding="async"
                                            />
                                        </div>
                                        <p class="mt-3 text-sm text-gray-500">📷 Scan to pay via any UPI app</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>

        <button id="scrollToTop" class="fixed bottom-6 right-6 text-white hidden z-50" aria-label="Scroll to top">
            <i class="fas fa-arrow-up text-lg" aria-hidden="true"></i>
        </button>

        <footer class="text-white py-12 bg-[#4c1d95]">
            <div class="container mx-auto px-4">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <div class="mb-8 md:mb-0 text-center md:text-left">
                        <h3 class="text-3xl font-bold mb-3">Swapnil Chemicals</h3>
                        <p class="text-slate-300 text-lg">Manufacturers & marketers of automobile cleaning products</p>
                        <p class="text-slate-300 mt-2">Jaipur • Bulk & Retail</p>
                    </div>
                    <div class="flex space-x-6">
                        <a
                            href="tel:9352470085"
                            class="w-12 h-12 bg-slate-700 rounded-xl flex items-center justify-center hover:bg-blue-600 transition"
                            aria-label="Call Swapnil Chemicals"
                            ><i class="fas fa-phone-alt icon-rotate-270 text-lg" aria-hidden="true"></i></a
                        ><a
                            href="mailto:swapnilchemicals10@gmail.com"
                            class="w-12 h-12 bg-slate-700 rounded-xl flex items-center justify-center hover:bg-red-600 transition"
                            aria-label="Email Swapnil Chemicals"
                            ><i class="fas fa-envelope text-lg" aria-hidden="true"></i
                        ></a>
                    </div>
                </div>
                <div class="border-t border-slate-700 mt-8 pt-8 text-center">
                    <p class="text-slate-300">
                        © <span id="copyrightYear">2026</span> Swapnil Chemicals. All rights reserved.
                    </p>
                    <p class="text-slate-400 text-sm mt-2">
                        MSME Registered • GST Certified • Quality Assured Products
                    </p>
                </div>
            </div>
        </footer>

        <div class="cart-panel hidden" id="cartPanel">
            <div class="cart-panel-header">
                <div>
                    <p class="font-bold text-base">Your Cart</p>
                    <p class="text-xs opacity-70">Swapnil Chemicals</p>
                </div>
                <button type="button" class="icon-btn-ghost" aria-label="Close cart">
                    <i class="fas fa-xmark" aria-hidden="true"></i>
                </button>
            </div>
            <div class="cart-items-list" id="cartItemsList">
                <div class="cart-empty-msg">
                    <i class="fas fa-shopping-cart text-3xl mb-3 block opacity-30"></i>Your cart is empty
                </div>
            </div>
            <div class="cart-panel-footer is-hidden" id="cartFooter">
                <div class="flex justify-between items-center mb-4">
                    <span class="text-base font-bold">Grand Total</span
                    ><span class="text-base font-bold text-blue-700" id="cartTotal">₹0</span>
                </div>

                <button type="button" id="cartGpayBtn" class="gpay-btn">
                    <img
                        src="https://www.gstatic.com/instantbuy/svg/dark_gpay.svg"
                        alt="Google Pay"
                        loading="lazy"
                        decoding="async"
                    />
                    Pay via GPay
                </button>

                <button
                    type="button"
                    id="cartClearBtn"
                    class="w-full mt-2 p-2 bg-transparent text-slate-400 text-xs cursor-pointer hover:text-slate-600 transition"
                >
                    Clear cart
                </button>
            </div>
        </div>

        <button
            id="aiAssistantBtn"
            type="button"
            class="ai-assistant-btn"
            aria-label="Open Swapnil Chemicals AI Assistant"
            aria-expanded="false"
        >
            <i class="fas fa-robot"></i>
            <span class="ai-assistant-btn-ring"></span>
        </button>

        <div
            class="assistant-panel hidden"
            id="assistantPanel"
            role="dialog"
            aria-label="Swapnil Chemicals AI Assistant"
        >
            <div class="assistant-panel-header">
                <div class="flex items-center gap-3">
                    <div class="assistant-avatar"><i class="fas fa-robot" aria-hidden="true"></i></div>
                    <div>
                        <p class="font-bold text-base leading-tight">Swapnil AI Assistant</p>
                        <p class="text-xs opacity-70">Products, pricing & orders</p>
                    </div>
                </div>
                <button type="button" class="icon-btn-ghost" aria-label="Close assistant">
                    <i class="fas fa-xmark" aria-hidden="true"></i>
                </button>
            </div>
            <div class="assistant-messages" id="assistantMessages" aria-live="polite"></div>
            <div class="assistant-quick-replies" id="assistantQuickReplies"></div>
            <form class="assistant-input-row" id="assistantForm">
                <input
                    type="text"
                    id="assistantInput"
                    class="assistant-input"
                    placeholder="Type your question..."
                    autocomplete="off"
                    maxlength="200"
                    aria-label="Ask the AI assistant a question"
                />
                <button type="button" id="voiceAssistantBtn" class="voice-btn-inline" aria-label="Ask by voice">
                    <i class="fas fa-microphone"></i>
                </button>
                <button type="submit" class="assistant-send-btn" aria-label="Send message">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </form>
        </div>

        <div id="enquiryModal">
            <div class="enquiry-modal-box" role="dialog" aria-modal="true" aria-label="Enquiry form" tabindex="-1">
                <div class="enquiry-modal-header">
                    <div>
                        <h2 class="text-white text-lg font-bold">📋 Enquiry Form</h2>
                        <p class="text-white/65 text-xs">Tell us about your requirements</p>
                    </div>
                    <button type="button" class="enquiry-close-btn" aria-label="Close enquiry form">
                        <i class="fas fa-xmark" aria-hidden="true"></i>
                    </button>
                </div>
                <div class="enquiry-body">
                    <div id="enquiryProductView">
                        <div class="enquiry-product-preview">
                            <img
                                id="enquiry-product-img"
                                src=""
                                alt="Selected Product"
                                loading="lazy"
                                decoding="async"
                            />
                            <div>
                                <p class="text-xs font-bold text-sky-700">Selected Product</p>
                                <p id="enquiry-product-name" class="font-bold text-gray-800"></p>
                                <p id="enquiry-product-rate" class="text-sm font-semibold text-blue-600 mt-1"></p>
                            </div>
                        </div>
                        <div class="enquiry-field-wrap">
                            <label class="text-xs font-bold text-gray-600 uppercase" id="enquiry-qty-label"
                                >Quantity <i class="fas fa-layer-group" aria-hidden="true"></i
                            ></label>
                            <div
                                id="enquiry-qty-buttons"
                                class="enquiry-qty-buttons"
                                role="group"
                                aria-labelledby="enquiry-qty-label"
                            ></div>
                            <input type="hidden" id="enquiry-qty-value" />
                        </div>
                        <div class="enquiry-field-wrap">
                            <label class="text-xs font-bold text-gray-600 uppercase" for="enquiry-details"
                                >Workshop Name & Address</label
                            ><textarea
                                id="enquiry-details"
                                class="enquiry-textarea"
                                rows="2"
                                placeholder="Any specific requirements..."
                            ></textarea>
                        </div>
                        <div class="enquiry-field-wrap">
                            <label class="text-xs font-bold text-gray-600 uppercase" for="enquiry-phone"
                                >Your Phone Number *</label
                            ><input
                                type="tel"
                                id="enquiry-phone"
                                class="enquiry-input"
                                maxlength="10"
                                inputmode="numeric"
                                placeholder="9876543210"
                            />
                            <p id="phone-error" class="text-red-500 text-xs hidden mt-1" role="alert">
                                Enter valid 10-digit number
                            </p>
                        </div>
                        <button type="button" class="enquiry-submit-btn">
                            <i class="fab fa-whatsapp" aria-hidden="true"></i> Send Enquiry via WhatsApp
                        </button>
                        <p class="text-center text-xs text-gray-400 mt-3">Directly sent to Swapnil Chemicals</p>
                    </div>
                    <div id="enquiryCartView" hidden></div>
                </div>
            </div>
        </div>

        <div id="addedCartModal">
            <div class="added-cart-box" role="dialog" aria-modal="true" aria-label="Added to cart" tabindex="-1">
                <button type="button" class="added-cart-close-btn" aria-label="Close">
                    <i class="fas fa-xmark" aria-hidden="true"></i>
                </button>
                <p class="added-cart-product-name" id="addedCartProductName"></p>
                <p class="added-cart-msg">has been added to your cart</p>
                <div class="added-cart-body">
                    <div class="added-cart-img-wrap">
                        <img id="addedCartProductImg" src="" alt="" loading="lazy" decoding="async" />
                    </div>
                    <div class="added-cart-qty">
                        <p>Qty</p>
                        <div class="added-cart-qty-ctrl">
                            <button type="button" data-step="-1" aria-label="Decrease quantity">&minus;</button>
                            <input type="text" id="addedCartQtyValue" value="1" readonly aria-live="polite" />
                            <button type="button" data-step="1" aria-label="Increase quantity">+</button>
                        </div>
                    </div>
                </div>
                <p class="added-cart-line">
                    There are <button type="button" class="linklike" id="addedCartItemsCount">0 items</button> in
                    your cart.
                </p>
                <p class="added-cart-subtotal">Cart Subtotal: <b id="addedCartSubtotal">₹0</b></p>
                <div class="added-cart-actions">
                    <button type="button" id="addedCartContinueBtn" class="added-cart-continue-btn">Continue</button>
                    <button type="button" class="added-cart-viewcart-btn">View Cart</button>
                </div>
            </div>
        </div>

        <div id="removeConfirmModal">
            <div
                class="remove-confirm-box"
                role="dialog"
                aria-modal="true"
                aria-label="Remove item from cart"
                tabindex="-1"
            >
                <div class="remove-confirm-icon"><i class="fas fa-trash-can" aria-hidden="true"></i></div>
                <p class="remove-confirm-title">Remove item?</p>
                <p class="remove-confirm-msg">
                    Are you sure you would like to remove <b id="removeConfirmProductName"></b> from the shopping cart?
                </p>
                <div class="added-cart-actions">
                    <button type="button" id="removeConfirmCancelBtn" class="added-cart-continue-btn">Cancel</button>
                    <button type="button" class="remove-confirm-ok-btn">
                        <i class="fas fa-trash-can" aria-hidden="true"></i> Remove
                    </button>
                </div>
            </div>
        </div>

        <script src="app.js" defer></script>
    </body>
</html>