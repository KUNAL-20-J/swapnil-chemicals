package com.swapnilchemicals.app.data

/**
 * Mirrors the `products` array from the original site's script (source lines ~2571-2659).
 *
 * [assetName] is the drawable resource name (no extension) the app looks for at runtime via
 * [com.swapnilchemicals.app.ui.components.ProductImage] — e.g. "dashboard_polish" resolves to
 * res/drawable/dashboard_polish.(png|jpg|webp|xml). Drop a real photo in under that name and no
 * code change is needed; until then [com.swapnilchemicals.app.ui.components.ProductImage] falls
 * back to a placeholder icon.
 */
data class Product(
    val id: Int,
    val name: String,
    val assetName: String,
    val price: Int,
    val unit: String,
    val hasLtOptions: Boolean,
    val qtyOptions: List<Int>? = null,
    val qtyLabel: String? = null,
    val description: String,
)

/** Default liter quantity chips for products with [Product.hasLtOptions] and no custom [Product.qtyOptions]. */
val DEFAULT_LT_OPTIONS = listOf(10, 35, 50)

/** Port of `getUnitLabel()` (source lines 2538-2541) — the unit string used in cart/enquiry line items. */
fun Product.unitLabel(): String {
    if (hasLtOptions && qtyOptions == null) return "Lt"
    return qtyOptions?.let { (qtyLabel ?: " pcs").trim() } ?: "pcs"
}

/** The quantity chip values shown on the product card / enquiry dialog for this product. */
fun Product.quantityOptions(): List<Int> = qtyOptions ?: if (hasLtOptions) DEFAULT_LT_OPTIONS else emptyList()

/** The label suffix for each quantity chip, e.g. "10 Lt" or "5 pcs". */
fun Product.quantityChipLabel(): String = qtyLabel?.trim() ?: "Lt"
