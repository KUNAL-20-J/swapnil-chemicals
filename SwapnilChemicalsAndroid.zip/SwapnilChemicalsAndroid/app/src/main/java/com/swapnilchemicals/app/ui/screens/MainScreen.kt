package com.swapnilchemicals.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.LazyColumn
import com.swapnilchemicals.app.R
import com.swapnilchemicals.app.data.Product
import com.swapnilchemicals.app.ui.components.FaqAccordion
import com.swapnilchemicals.app.ui.components.FaqItem
import com.swapnilchemicals.app.ui.components.ProductCard
import com.swapnilchemicals.app.ui.components.SectionHeader
import com.swapnilchemicals.app.ui.theme.AccentOrange
import com.swapnilchemicals.app.ui.theme.HeroBandBottom
import com.swapnilchemicals.app.ui.theme.HeroBandTop
import com.swapnilchemicals.app.util.QrCodeGenerator
import kotlinx.coroutines.launch

/**
 * Assembles the hero / business-details / products / FAQ / contact / footer sections (source
 * lines 1731-2220) into one scrollable screen. The header (logo, cart icon) lives in
 * `MainActivity`'s `Scaffold` topBar instead of scrolling with the page, since it's `position:
 * sticky` in the original (source line 1731).
 */
@Composable
fun MainScreen(
    listState: LazyListState,
    products: List<Product>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    isSearchListening: Boolean,
    searchVoiceAvailable: Boolean,
    onVoiceSearchClick: () -> Unit,
    onAddToCart: (Product, Int) -> Unit,
    onOpenEnquiry: (Product) -> Unit,
    onDial: (String) -> Unit,
    onEmail: (String) -> Unit,
    onCopy: (label: String, text: String) -> Unit,
    onUpiPay: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    val numProductRows = (products.size + 1) / 2
    val productsHeaderIndex = 2
    val faqIndex = productsHeaderIndex + 1 + numProductRows
    val contactIndex = faqIndex + 1

    LazyColumn(state = listState, modifier = modifier) {
        item {
            HeroSection(
                onViewProducts = { scope.launch { listState.animateScrollToItem(productsHeaderIndex) } },
                onContactNow = { scope.launch { listState.animateScrollToItem(contactIndex) } },
            )
        }
        item { BusinessDetailsSection(onDial = onDial, onEmail = onEmail, onCopy = onCopy) }
        item {
            ProductsHeader(
                query = searchQuery,
                onQueryChange = onSearchQueryChange,
                isListening = isSearchListening,
                voiceAvailable = searchVoiceAvailable,
                onVoiceClick = onVoiceSearchClick,
            )
        }
        if (products.isEmpty()) {
            item {
                Text(
                    text = stringResource(R.string.search_no_results, searchQuery),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 24.dp),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            products.chunked(2).forEach { row ->
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        row.forEach { product ->
                            ProductCard(
                                product = product,
                                onAddToCart = onAddToCart,
                                onOpenEnquiry = onOpenEnquiry,
                                onCallClick = { onDial("9352470085") },
                                modifier = Modifier.weight(1f),
                            )
                        }
                        if (row.size == 1) Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
        item { FaqSection() }
        item { ContactSection(onDial = onDial, onEmail = onEmail, onCopy = onCopy, onUpiPay = onUpiPay) }
        item { FooterSection(onDial = onDial, onEmail = onEmail) }
    }
}

@Composable
private fun HeroSection(onViewProducts: () -> Unit, onContactNow: () -> Unit) {
    Column {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(HeroBandTop)
                .padding(top = 48.dp, bottom = 24.dp, start = 20.dp, end = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = stringResource(R.string.hero_title_line1),
                style = MaterialTheme.typography.headlineLarge,
                color = Color.White,
                textAlign = TextAlign.Center,
            )
            Text(
                text = stringResource(R.string.hero_title_line2),
                style = MaterialTheme.typography.headlineLarge,
                color = Color(0xFF60A5FA),
                textAlign = TextAlign.Center,
            )
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(HeroBandBottom)
                .padding(top = 24.dp, bottom = 40.dp, start = 20.dp, end = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = stringResource(R.string.hero_body),
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.9f),
                textAlign = TextAlign.Center,
            )
            Row(
                modifier = Modifier.padding(top = 28.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Button(onClick = onViewProducts, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))) {
                    Icon(Icons.Filled.Business, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text(stringResource(R.string.cta_view_products))
                }
                Button(onClick = onContactNow, colors = ButtonDefaults.buttonColors(containerColor = AccentOrange)) {
                    Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text(stringResource(R.string.cta_contact_now))
                }
            }
        }
    }
}

@Composable
private fun BusinessDetailsSection(
    onDial: (String) -> Unit,
    onEmail: (String) -> Unit,
    onCopy: (String, String) -> Unit,
) {
    Column(modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)) {
        SectionHeader(
            title = stringResource(R.string.section_business_details),
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Spacer(modifier = Modifier.padding(top = 12.dp))
        val entries = listOf(
            Triple(Icons.Filled.Person, stringResource(R.string.founder_label), stringResource(R.string.founder_name)),
            Triple(Icons.Filled.Call, stringResource(R.string.phone_label), "${stringResource(R.string.phone_primary)} / ${stringResource(R.string.phone_secondary)}"),
            Triple(Icons.Filled.Receipt, stringResource(R.string.gst_label), stringResource(R.string.gst_value)),
            Triple(Icons.Filled.Email, stringResource(R.string.email_label), stringResource(R.string.email_value)),
            Triple(Icons.Filled.Badge, stringResource(R.string.msme_label), stringResource(R.string.msme_value)),
            Triple(Icons.Filled.VerifiedUser, stringResource(R.string.udyam_label), stringResource(R.string.udyam_value)),
            Triple(Icons.Filled.Business, stringResource(R.string.brn_label), stringResource(R.string.brn_value)),
        )
        entries.chunked(2).forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                row.forEach { (icon, label, value) ->
                    BusinessDetailCard(
                        icon = icon,
                        label = label,
                        value = value,
                        showCopy = label == stringResource(R.string.gst_label),
                        onCopy = { onCopy(label, value) },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (row.size == 1) Spacer(modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun BusinessDetailCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    showCopy: Boolean,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier
                    .size(44.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                    .padding(10.dp),
            )
            Spacer(modifier = Modifier.padding(start = 12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            }
            if (showCopy) {
                IconButton(onClick = onCopy) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = "Copy $label")
                }
            }
        }
    }
}

@Composable
private fun ProductsHeader(
    query: String,
    onQueryChange: (String) -> Unit,
    isListening: Boolean,
    voiceAvailable: Boolean,
    onVoiceClick: () -> Unit,
) {
    Column(modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)) {
        SectionHeader(
            title = stringResource(R.string.section_products),
            subtitle = stringResource(R.string.products_subtitle),
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            placeholder = { Text(stringResource(R.string.search_hint)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (voiceAvailable) {
                    IconButton(onClick = onVoiceClick) {
                        Icon(
                            Icons.Filled.Mic,
                            contentDescription = "Search by voice",
                            tint = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            },
            singleLine = true,
        )
    }
}

@Composable
private fun FaqSection() {
    Column(modifier = Modifier.padding(vertical = 16.dp)) {
        SectionHeader(
            title = stringResource(R.string.section_faq),
            subtitle = stringResource(R.string.faq_subtitle),
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Spacer(modifier = Modifier.padding(top = 12.dp))
        val items = listOf(
            FaqItem(stringResource(R.string.faq_q1), stringResource(R.string.faq_a1)),
            FaqItem(stringResource(R.string.faq_q2), stringResource(R.string.faq_a2)),
            FaqItem(stringResource(R.string.faq_q3), stringResource(R.string.faq_a3)),
            FaqItem(stringResource(R.string.faq_q4), stringResource(R.string.faq_a4)),
            FaqItem(stringResource(R.string.faq_q5), stringResource(R.string.faq_a5)),
            FaqItem(stringResource(R.string.faq_q6), stringResource(R.string.faq_a6)),
        )
        FaqAccordion(items = items, modifier = Modifier.padding(horizontal = 20.dp))
    }
}

@Composable
private fun ContactSection(
    onDial: (String) -> Unit,
    onEmail: (String) -> Unit,
    onCopy: (String, String) -> Unit,
    onUpiPay: () -> Unit,
) {
    Column(modifier = Modifier.padding(vertical = 16.dp)) {
        SectionHeader(
            title = stringResource(R.string.section_contact),
            subtitle = stringResource(R.string.contact_subtitle),
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Spacer(modifier = Modifier.padding(top = 12.dp))
        val phonePrimary = stringResource(R.string.phone_primary)
        val phoneSecondary = stringResource(R.string.phone_secondary)
        val emailValue = stringResource(R.string.email_value)
        val upiId = stringResource(R.string.upi_id)
        Column(modifier = Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(shape = RoundedCornerShape(18.dp)) {
                Row(modifier = Modifier.padding(20.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.padding(start = 16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.phone_label), style = MaterialTheme.typography.titleMedium)
                        Text(phonePrimary, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 4.dp))
                        Text(phoneSecondary, color = MaterialTheme.colorScheme.primary)
                    }
                    OutlinedButton(onClick = { onDial(phonePrimary) }) { Text("Call") }
                }
            }
            Card(shape = RoundedCornerShape(18.dp)) {
                Row(modifier = Modifier.padding(20.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.padding(start = 16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.email_label), style = MaterialTheme.typography.titleMedium)
                        Text(emailValue, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 4.dp))
                    }
                    OutlinedButton(onClick = { onEmail(emailValue) }) { Text("Email") }
                }
            }
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(modifier = Modifier.padding(20.dp).fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.QrCode2, contentDescription = null, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.padding(start = 16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Google Pay", style = MaterialTheme.typography.titleMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    stringResource(R.string.upi_pay_label),
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                IconButton(onClick = { onCopy("UPI ID", upiId) }) {
                                    Icon(Icons.Filled.ContentCopy, contentDescription = "Copy UPI ID", modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                    Button(
                        onClick = onUpiPay,
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34A853), contentColor = Color.White),
                    ) {
                        Text("Pay via UPI / GPay")
                    }

                    // Generated on-device (source used a remote https://api.qrserver.com image, line 2166).
                    val upiUri = "upi://pay?pa=$upiId&pn=Swapnil%20Chemicals&cu=INR"
                    val qrBitmap = remember(upiUri) { QrCodeGenerator.generate(upiUri, sizePx = 300) }
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 16.dp), contentAlignment = Alignment.Center) {
                        Image(
                            bitmap = qrBitmap,
                            contentDescription = "UPI QR code",
                            modifier = Modifier
                                .size(140.dp)
                                .background(Color.White, RoundedCornerShape(12.dp))
                                .padding(8.dp),
                        )
                    }
                    Text(
                        stringResource(R.string.scan_to_pay),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

@Composable
private fun FooterSection(onDial: (String) -> Unit, onEmail: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(HeroBandTop)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge, color = Color.White)
        Text(
            stringResource(R.string.tagline),
            color = Color.White.copy(alpha = 0.75f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp),
        )
        Row(modifier = Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            IconButton(onClick = { onDial("9352470085") }) {
                Icon(Icons.Filled.Call, contentDescription = "Call", tint = Color.White)
            }
            IconButton(onClick = { onEmail("swapnilchemicals10@gmail.com") }) {
                Icon(Icons.Filled.Email, contentDescription = "Email", tint = Color.White)
            }
        }
        val currentYear = remember { java.util.Calendar.getInstance().get(java.util.Calendar.YEAR) }
        Text(
            stringResource(R.string.footer_rights, currentYear),
            color = Color.White.copy(alpha = 0.7f),
            modifier = Modifier.padding(top = 20.dp),
        )
        Text(
            stringResource(R.string.footer_badges),
            color = Color.White.copy(alpha = 0.6f),
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}
