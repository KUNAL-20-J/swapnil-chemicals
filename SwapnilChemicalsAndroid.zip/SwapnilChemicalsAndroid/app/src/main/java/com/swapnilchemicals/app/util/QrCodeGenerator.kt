package com.swapnilchemicals.app.util

import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter

/**
 * Generates the UPI QR code on-device rather than fetching it from a remote image service
 * (`https://api.qrserver.com/...`, source line 2166) — keeps the app fully offline-capable
 * for this feature, per the approved plan.
 */
object QrCodeGenerator {
    fun generate(content: String, sizePx: Int = 512): ImageBitmap {
        val matrix = MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, sizePx, sizePx)
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.RGB_565)
        for (x in 0 until sizePx) {
            for (y in 0 until sizePx) {
                bitmap.setPixel(x, y, if (matrix.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }
        return bitmap.asImageBitmap()
    }
}
