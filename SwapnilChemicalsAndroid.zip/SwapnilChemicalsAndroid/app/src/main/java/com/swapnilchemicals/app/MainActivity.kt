package com.swapnilchemicals.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.swapnilchemicals.app.data.Product
import com.swapnilchemicals.app.ui.assistant.AssistantPanel
import com.swapnilchemicals.app.ui.cart.CartPanel
import com.swapnilchemicals.app.ui.components.AppHeader
import com.swapnilchemicals.app.ui.dialogs.AddedToCartDialog
import com.swapnilchemicals.app.ui.dialogs.CartEnquiryDialog
import com.swapnilchemicals.app.ui.dialogs.EnquiryDialog
import com.swapnilchemicals.app.ui.dialogs.RemoveConfirmDialog
import com.swapnilchemicals.app.ui.screens.MainScreen
import com.swapnilchemicals.app.ui.theme.SwapnilChemicalsTheme
import com.swapnilchemicals.app.util.Deeplinks
import com.swapnilchemicals.app.util.EnquiryMessages
import com.swapnilchemicals.app.util.VoiceRecognitionController
import com.swapnilchemicals.app.util.WhatsApp
import com.swapnilchemicals.app.viewmodel.AssistantViewModel
import com.swapnilchemicals.app.viewmodel.CartViewModel
import com.swapnilchemicals.app.viewmodel.ProductViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SwapnilChemicalsTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AppRoot()
                }
            }
        }
    }
}

/**
 * Wires the three ViewModels and all panels/dialogs together — the native equivalent of the
 * module-level app state (`cart`, `currentEnquiryProduct`, `addedCartModalKey`,
 * `pendingRemoveKey`, source lines 2446-2451) and the delegated click-handler map
 * (`ACTION_HANDLERS`, source lines 3326-3352).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val cartViewModel: CartViewModel = viewModel()
    val productViewModel: ProductViewModel = viewModel()
    val assistantViewModel: AssistantViewModel = viewModel()

    val cartState by cartViewModel.state.collectAsStateWithLifecycle()
    val searchQuery by productViewModel.query.collectAsStateWithLifecycle()
    val filteredProducts by productViewModel.filteredProducts.collectAsStateWithLifecycle()
    val assistantMessages by assistantViewModel.messages.collectAsStateWithLifecycle()

    val listState = rememberLazyListState()

    var cartPanelVisible by remember { mutableStateOf(false) }
    var assistantPanelVisible by remember { mutableStateOf(false) }
    var enquiryProduct by remember { mutableStateOf<Product?>(null) }
    var addedCartKey by remember { mutableStateOf<String?>(null) }
    var pendingRemove by remember { mutableStateOf<Pair<String, String>?>(null) }
    var cartEnquiryOpen by remember { mutableStateOf(false) }

    val cartSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val assistantSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    fun closeCartPanel() {
        scope.launch { cartSheetState.hide() }.invokeOnCompletion {
            if (!cartSheetState.isVisible) cartPanelVisible = false
        }
    }

    fun closeAssistantPanel() {
        scope.launch { assistantSheetState.hide() }.invokeOnCompletion {
            if (!assistantSheetState.isVisible) assistantPanelVisible = false
        }
    }

    // Voice input: one RECORD_AUDIO permission shared by the search mic and the assistant mic
    // (the original has no such step — browsers prompt for microphone access automatically).
    var recordAudioGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        recordAudioGranted = granted
        if (!granted) {
            Toast.makeText(context, "Microphone permission is needed for voice input", Toast.LENGTH_SHORT).show()
        }
    }

    val searchVoiceController = remember { VoiceRecognitionController(context) }
    val assistantVoiceController = remember { VoiceRecognitionController(context) }
    var isSearchListening by remember { mutableStateOf(false) }
    var isAssistantListening by remember { mutableStateOf(false) }
    // Mirrors `isSpeechRecognitionSupported()` (source line 3132-3134) — hides the mic button
    // entirely on devices/builds with no speech recognizer, matching `btn.remove()`.
    val voiceAvailable = remember { searchVoiceController.isAvailable() }

    DisposableEffect(Unit) {
        onDispose {
            searchVoiceController.stop()
            assistantVoiceController.stop()
        }
    }

    fun startSearchVoice() {
        if (!recordAudioGranted) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        searchVoiceController.start(
            onListeningChange = { isSearchListening = it },
            onResult = { transcript -> productViewModel.updateQuery(transcript) },
        )
    }

    fun startAssistantVoice() {
        if (!recordAudioGranted) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        assistantVoiceController.start(
            onListeningChange = { isAssistantListening = it },
            onResult = { transcript -> assistantViewModel.handleQuery(transcript) },
        )
    }

    fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(context, "$label copied", Toast.LENGTH_SHORT).show()
    }

    Scaffold(
        topBar = {
            AppHeader(
                cartItemCount = cartState.totalItems,
                onCartClick = { cartPanelVisible = true },
            )
        },
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            MainScreen(
                listState = listState,
                products = filteredProducts,
                searchQuery = searchQuery,
                onSearchQueryChange = productViewModel::updateQuery,
                isSearchListening = isSearchListening,
                searchVoiceAvailable = voiceAvailable,
                onVoiceSearchClick = { startSearchVoice() },
                onAddToCart = { product, qty ->
                    cartViewModel.addToCart(product, qty)
                    addedCartKey = "${product.id}_$qty"
                },
                onOpenEnquiry = { product -> enquiryProduct = product },
                onDial = { number -> Deeplinks.dial(context, number) },
                onEmail = { address -> Deeplinks.email(context, address) },
                onCopy = ::copyToClipboard,
                onUpiPay = { Deeplinks.payViaUpi(context) },
            )

            // Port of `initScrollToTop()` (source lines 3647-3657) — shown once the user has
            // scrolled a little way down the product grid rather than at a raw pixel offset.
            val showScrollTop by remember { derivedStateOf { listState.firstVisibleItemIndex > 3 } }
            AnimatedVisibility(
                visible = showScrollTop,
                modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            ) {
                FloatingActionButton(onClick = { scope.launch { listState.animateScrollToItem(0) } }) {
                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Scroll to top")
                }
            }

            FloatingActionButton(
                onClick = {
                    assistantPanelVisible = true
                    assistantViewModel.greetIfNeeded()
                },
                modifier = Modifier.align(Alignment.BottomStart).padding(20.dp),
                containerColor = MaterialTheme.colorScheme.primary,
            ) {
                Icon(Icons.Filled.SmartToy, contentDescription = "Open AI Assistant", tint = Color.White)
            }
        }
    }

    if (cartPanelVisible) {
        CartPanel(
            state = cartState,
            sheetState = cartSheetState,
            onDismiss = { closeCartPanel() },
            onChangeQty = { key, delta -> cartViewModel.changeQuantity(key, delta) },
            onRequestRemove = { key, name -> pendingRemove = key to name },
            onClear = {
                cartViewModel.clear()
                closeCartPanel()
            },
            onPayGpay = { cartEnquiryOpen = true },
        )
    }

    if (assistantPanelVisible) {
        AssistantPanel(
            messages = assistantMessages,
            quickReplies = assistantViewModel.quickReplies,
            sheetState = assistantSheetState,
            isListening = isAssistantListening,
            voiceAvailable = voiceAvailable,
            onDismiss = { closeAssistantPanel() },
            onSend = { text -> assistantViewModel.handleQuery(text) },
            onQuickReply = { query -> assistantViewModel.handleQuery(query) },
            onWhatsAppFallback = { query ->
                WhatsApp.openChat(context, "Hi Swapnil Chemicals, I have a question: $query")
            },
            onPhoneClick = { number -> Deeplinks.dial(context, number) },
            onEmailClick = { address -> Deeplinks.email(context, address) },
            onMicClick = {
                if (isAssistantListening) assistantVoiceController.stop() else startAssistantVoice()
            },
        )
    }

    enquiryProduct?.let { product ->
        EnquiryDialog(
            product = product,
            onDismiss = { enquiryProduct = null },
            onSubmit = { qtyLabel, phone, details ->
                WhatsApp.openChat(context, EnquiryMessages.singleProduct(product, qtyLabel, phone, details))
                enquiryProduct = null
            },
        )
    }

    addedCartKey?.let { key ->
        val uiLine = cartViewModel.lineByKey(key)
        if (uiLine != null) {
            AddedToCartDialog(
                uiLine = uiLine,
                totalItems = cartState.totalItems,
                grandTotal = cartState.grandTotal,
                onDismiss = { addedCartKey = null },
                onChangeQty = { delta -> cartViewModel.changeQuantity(key, delta) },
                onViewCart = {
                    addedCartKey = null
                    cartPanelVisible = true
                },
            )
        } else {
            // The line was removed from elsewhere (e.g. cleared) while this dialog was open.
            addedCartKey = null
        }
    }

    pendingRemove?.let { (key, name) ->
        RemoveConfirmDialog(
            productName = name,
            onDismiss = { pendingRemove = null },
            onConfirm = {
                cartViewModel.removeLine(key)
                pendingRemove = null
            },
        )
    }

    if (cartEnquiryOpen) {
        CartEnquiryDialog(
            lines = cartState.lines,
            onDismiss = { cartEnquiryOpen = false },
            onSubmit = { phone, details ->
                WhatsApp.openChat(context, EnquiryMessages.cart(cartState.lines, details, phone))
                cartEnquiryOpen = false
            },
        )
    }
}
