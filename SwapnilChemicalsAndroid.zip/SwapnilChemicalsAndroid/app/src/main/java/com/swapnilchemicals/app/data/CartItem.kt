package com.swapnilchemicals.app.data

import kotlinx.serialization.Serializable

/**
 * One cart line, keyed by `${productId}_${selectedQty}` — the same composite key the original
 * JS `cart` object uses (source line 2673: `` `${productId}_${selectedQty}` ``), so the same
 * product added at two different quantity tiers (e.g. 10 Lt and 35 Lt) becomes two separate lines.
 *
 * [selectedQty] is the chosen quantity-chip value (e.g. 10, 35, 50 for Lt products, or 5, 10, 20
 * for Micro Towels) and [quantity] is how many times that line has been added/incremented — total
 * units for the line is `selectedQty * quantity`, matching `totalQty = selectedQty * qty` (source
 * line 2767).
 */
@Serializable
data class CartLine(
    val productId: Int,
    val selectedQty: Int,
    val quantity: Int,
) {
    val key: String get() = "${productId}_$selectedQty"
}

/** Persisted shape written to DataStore, mirroring `localStorage.setItem(APP.CART_STORAGE_KEY, ...)`. */
@Serializable
data class CartSnapshot(val lines: List<CartLine> = emptyList())
