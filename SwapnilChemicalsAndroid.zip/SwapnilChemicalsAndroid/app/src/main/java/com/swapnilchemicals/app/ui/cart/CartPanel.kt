package com.swapnilchemicals.app.ui.cart

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.swapnilchemicals.app.data.unitLabel
import com.swapnilchemicals.app.ui.theme.DangerRed
import com.swapnilchemicals.app.ui.theme.WhatsAppGreen
import com.swapnilchemicals.app.util.formatCurrency
import com.swapnilchemicals.app.viewmodel.CartUiLine
import com.swapnilchemicals.app.viewmodel.CartUiState

/**
 * Native equivalent of the fixed cart panel + `updateCartUI()` rendering (source lines
 * 2222-2259, 2738-2789). A `ModalBottomSheet` replaces the original's floating top-right panel —
 * a bottom sheet is the idiomatic Android pattern for a cart drawer, not a like-for-like position.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartPanel(
    state: CartUiState,
    sheetState: SheetState,
    onDismiss: () -> Unit,
    onChangeQty: (key: String, delta: Int) -> Unit,
    onRequestRemove: (key: String, productName: String) -> Unit,
    onClear: () -> Unit,
    onPayGpay: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(modifier = Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(text = "Your Cart", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Swapnil Chemicals",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close cart")
                }
            }
            Spacer(modifier = Modifier.padding(top = 12.dp))

            if (state.isEmpty) {
                Box(modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp)) {
                    Text(
                        text = "Your cart is empty",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 340.dp)) {
                    items(state.lines, key = { it.line.key }) { uiLine ->
                        CartLineRow(uiLine, onChangeQty, onRequestRemove)
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("Grand Total", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        formatCurrency(state.grandTotal),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }

                // The original's "Pay via GPay" button actually triggers the cart enquiry-via-WhatsApp
                // flow, not a UPI payment — its label is rewritten to "Enquiry ₹total" by
                // `updateCartUI()` as soon as the cart is non-empty (source lines 2246-2255, 2782-2788).
                Button(
                    onClick = onPayGpay,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen, contentColor = Color.White),
                ) {
                    Icon(Icons.Filled.ShoppingCart, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text("Enquiry ${formatCurrency(state.grandTotal)}")
                }

                TextButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) {
                    Text("Clear cart", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun CartLineRow(
    uiLine: CartUiLine,
    onChangeQty: (String, Int) -> Unit,
    onRequestRemove: (String, String) -> Unit,
) {
    val product = uiLine.product
    val unit = product.unitLabel()
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(product.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(
                "${uiLine.totalUnits} $unit × ${formatCurrency(product.price)}/$unit",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            QtyStepButton(symbol = "−") { onChangeQty(uiLine.line.key, -1) }
            Text(
                "${uiLine.totalUnits}$unit",
                modifier = Modifier.widthIn(min = 44.dp),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodySmall,
            )
            QtyStepButton(symbol = "+") { onChangeQty(uiLine.line.key, 1) }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                formatCurrency(uiLine.lineTotal),
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
            IconButton(
                onClick = { onRequestRemove(uiLine.line.key, product.name) },
                modifier = Modifier.size(28.dp),
            ) {
                Icon(Icons.Filled.Delete, contentDescription = "Remove ${product.name} from cart", tint = DangerRed)
            }
        }
    }
}

@Composable
private fun QtyStepButton(symbol: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(28.dp)) {
        Text(symbol, style = MaterialTheme.typography.titleMedium)
    }
}
