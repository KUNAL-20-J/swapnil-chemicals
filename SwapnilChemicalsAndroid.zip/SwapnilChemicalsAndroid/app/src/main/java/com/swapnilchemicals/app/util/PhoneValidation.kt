package com.swapnilchemicals.app.util

/** Port of `isValidIndianMobile()` (source line 2501-2503). */
private val INDIAN_MOBILE_REGEX = Regex("^[6-9]\\d{9}$")

fun isValidIndianMobile(value: String): Boolean = INDIAN_MOBILE_REGEX.matches(value.trim())
