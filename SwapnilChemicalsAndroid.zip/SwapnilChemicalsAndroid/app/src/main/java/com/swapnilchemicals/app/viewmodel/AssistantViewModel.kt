package com.swapnilchemicals.app.viewmodel

import androidx.lifecycle.ViewModel
import com.swapnilchemicals.app.data.Product
import com.swapnilchemicals.app.data.ProductCatalog
import com.swapnilchemicals.app.util.formatCurrency
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicLong

enum class AssistantRole { BOT, USER }

/**
 * [text] may contain `**bold**` markers (product names, registration numbers) plus bare phone
 * numbers / email addresses — `ui.components.toAssistantAnnotatedString()` turns those into
 * bold spans and tap-to-call/email links at render time, replacing the original's inline
 * `<b>`/`<a href="tel:...">` HTML (source lines 3512, 3568 etc).
 */
data class AssistantMessage(
    val id: Long,
    val role: AssistantRole,
    val text: String,
    /** Non-null on a fallback bot reply — renders an "Ask on WhatsApp" chip that sends this text (source lines 3608-3633). */
    val whatsAppFallbackQuery: String? = null,
)

data class QuickReply(val label: String, val query: String)

/** Port of the assistant chat logic (source lines 3455-3645). */
class AssistantViewModel : ViewModel() {
    private val idGen = AtomicLong(0)
    private var hasGreeted = false

    private val _messages = MutableStateFlow<List<AssistantMessage>>(emptyList())
    val messages: StateFlow<List<AssistantMessage>> = _messages.asStateFlow()

    /** Port of `ASSISTANT_QUICK_REPLIES` (source lines 3455-3461). */
    val quickReplies = listOf(
        QuickReply("Our Products", "What products do you sell?"),
        QuickReply("Pricing", "What are your prices?"),
        QuickReply("Bulk Orders", "Do you supply bulk orders?"),
        QuickReply("Contact Us", "How can I contact you?"),
        QuickReply("Payment", "How can I pay?"),
    )

    /** Port of the first-open greeting in `toggleAssistant()` (source lines 3470-3477). */
    fun greetIfNeeded() {
        if (hasGreeted) return
        hasGreeted = true
        appendBot(
            "Hi! 👋 I'm the Swapnil Chemicals assistant. I can help with product info, " +
                "pricing, bulk orders, payment & contact details. What would you like to know?",
        )
    }

    /** Port of `handleAssistantQuery()` (source lines 3614-3634). */
    fun handleQuery(rawText: String) {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) return
        appendUser(trimmed)
        val reply = buildReply(trimmed)
        _messages.value += AssistantMessage(
            id = nextId(),
            role = AssistantRole.BOT,
            text = reply.text,
            whatsAppFallbackQuery = if (reply.isFallback) trimmed else null,
        )
    }

    private fun appendUser(text: String) {
        _messages.value += AssistantMessage(nextId(), AssistantRole.USER, text)
    }

    private fun appendBot(text: String) {
        _messages.value += AssistantMessage(nextId(), AssistantRole.BOT, text)
    }

    private fun nextId(): Long = idGen.incrementAndGet()

    private data class Reply(val text: String, val isFallback: Boolean)

    private fun formatProductLine(p: Product): String = "**${p.name}** — ${formatCurrency(p.price)} / ${p.unit}"

    /** Port of `uniqueProductList()` (source lines 3515-3517) — de-dupes by name+price+unit, preserving order. */
    private fun uniqueProductList(): List<Product> =
        ProductCatalog.products.distinctBy { "${it.name}|${it.price}|${it.unit}" }

    /** Port of `findProductsByQuery()` (source lines 3519-3521). */
    private fun findProductsByQuery(text: String): List<Product> =
        ProductCatalog.products.filter { text.contains(it.name.lowercase()) }

    /** Direct port of `buildAssistantReply()` (source lines 3523-3612) — same intent order, first match wins. */
    private fun buildReply(rawText: String): Reply {
        val text = rawText.lowercase().trim()

        if (Regex("\\b(hi|hello|hey|namaste)\\b").containsMatchIn(text)) {
            return Reply(
                "Hello! How can I help you today? You can ask about our products, prices, bulk orders, payment or contact details.",
                false,
            )
        }

        if (Regex("\\b(bye|thanks|thank you|thank)\\b").containsMatchIn(text)) {
            return Reply("You're welcome! Feel free to reach out anytime. 🙏", false)
        }

        if (Regex("\\b(product|catalog|range|items?)\\b").containsMatchIn(text) ||
            Regex("what.*(sell|make|manufacture)").containsMatchIn(text)
        ) {
            val lines = uniqueProductList().joinToString("\n", transform = ::formatProductLine)
            return Reply(
                "Here's our product range:\n\n$lines\n\nTap \"Add to Cart\" or \"Enquiry\" on any product card above for quantity options.",
                false,
            )
        }

        if (Regex("\\b(price|cost|rate|rates|pricing|how much)\\b").containsMatchIn(text)) {
            val matches = findProductsByQuery(text)
            if (matches.isNotEmpty()) {
                val lines = matches.joinToString("\n", transform = ::formatProductLine)
                val suffix = if (matches.size > 1) {
                    "Let us know which variant you need, or ask about \"bulk orders\" for larger quantities."
                } else {
                    "Larger quantities are available for bulk orders — ask me about \"bulk orders\" for details."
                }
                return Reply("$lines\n\n$suffix", false)
            }
            val lines = uniqueProductList().joinToString("\n", transform = ::formatProductLine)
            return Reply("Here are our current prices:\n\n$lines", false)
        }

        if (Regex("\\b(bulk|wholesale|distributor|discount|large quantity|retail)\\b").containsMatchIn(text)) {
            return Reply(
                "We supply both bulk and retail quantities. For bulk/wholesale pricing, please call us at " +
                    "9352470085 or 9024598298, or use the \"Enquiry\" button on a product to send your " +
                    "requirement on WhatsApp.",
                false,
            )
        }

        if (Regex("\\b(contact|phone|number|call|reach|mobile)\\b").containsMatchIn(text)) {
            return Reply(
                "You can reach Swapnil Chemicals at:\n📞 9352470085\n📞 9024598298\n" +
                    "✉️ swapnilchemicals10@gmail.com",
                false,
            )
        }

        if (Regex("\\b(email|mail)\\b").containsMatchIn(text)) {
            return Reply("Our email is swapnilchemicals10@gmail.com", false)
        }

        if (Regex("\\b(where|location|address|based|jaipur|city)\\b").containsMatchIn(text)) {
            return Reply("We're based in Jaipur, Rajasthan, and supply both bulk and retail orders.", false)
        }

        if (Regex("\\b(gst|msme|udyam|brn|registration|license|legal|certificate)\\b").containsMatchIn(text)) {
            return Reply(
                "Swapnil Chemicals is a registered business:\nGST: **08CIJPS1734A1ZE**\nMSME: **MSME/2020/6194**\n" +
                    "Udyam: **UDYAM-RJ-17-0022468**\nBRN: **8005220072000968**",
                false,
            )
        }

        if (Regex("\\b(pay|payment|upi|gpay|google pay)\\b").containsMatchIn(text)) {
            return Reply(
                "You can pay via Google Pay / UPI to **9352470085**, or scan the QR code in the Contact section. " +
                    "Call us to discuss other payment arrangements.",
                false,
            )
        }

        if (Regex("\\b(order|buy|purchase)\\b").containsMatchIn(text)) {
            return Reply(
                "To order: pick a product above, choose a quantity, and tap \"Add to Cart\" (then \"Pay via GPay\" " +
                    "in your cart), or tap \"Enquiry\" to send your requirement directly to us on WhatsApp.",
                false,
            )
        }

        return Reply(
            "I can help with product info, pricing, bulk orders, payment and contact details. For anything else, " +
                "let's connect you with our team directly on WhatsApp.",
            true,
        )
    }
}
