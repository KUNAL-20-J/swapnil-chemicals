package com.swapnilchemicals.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Reusable quantity-chip selector, shared by the product card and the enquiry dialog —
 * mirrors `.qty-btn`/`.active` and `.enquiry-qty-btn`/`.active` (source lines 3012-3030, 3238-3288). */
@Composable
fun QtyChipRow(
    options: List<Int>,
    unitLabel: String,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { qty ->
            FilterChip(
                selected = qty == selected,
                onClick = { onSelect(qty) },
                label = { Text("$qty $unitLabel") },
            )
        }
    }
}
