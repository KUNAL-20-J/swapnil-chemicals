package com.swapnilchemicals.app.util

import com.swapnilchemicals.app.data.Product
import kotlin.math.min

/** Direct port of `SEARCH_SYNONYMS` (source lines 3049-3060). */
private val SEARCH_SYNONYMS = mapOf(
    "cloth" to "towel",
    "rag" to "towel",
    "wiper" to "towel",
    "shine" to "polish",
    "shiner" to "polish",
    "spray" to "gun",
    "sprayer" to "gun",
    "cleaning" to "wash",
    "clean" to "wash",
    "shampoo" to "wash",
)

/** Port of `levenshteinDistance()` (source lines 3062-3081). */
fun levenshteinDistance(a: String, b: String): Int {
    if (a == b) return 0
    if (a.isEmpty()) return b.length
    if (b.isEmpty()) return a.length

    var prevRow = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
        var prevDiag = prevRow[0]
        prevRow[0] = i
        for (j in 1..b.length) {
            val temp = prevRow[j]
            prevRow[j] = minOf(
                prevRow[j] + 1,
                prevRow[j - 1] + 1,
                prevDiag + if (a[i - 1] == b[j - 1]) 0 else 1,
            )
            prevDiag = temp
        }
    }
    return prevRow[b.length]
}

/** Port of `fuzzyWordsMatch()` (source lines 3083-3087). */
fun fuzzyWordsMatch(a: String, b: String): Boolean {
    if (a == b || a.contains(b) || b.contains(a)) return true
    val maxDistance = if (min(a.length, b.length) > 5) 2 else 1
    return levenshteinDistance(a, b) <= maxDistance
}

/** Port of `scoreProductAgainstQuery()` (source lines 3089-3101). */
private fun scoreProductAgainstQuery(product: Product, queryWords: List<String>): Int {
    val haystack = "${product.name} ${product.description}".lowercase()
    val haystackWords = haystack.split(Regex("\\s+"))
    var score = 0
    queryWords.forEach { word ->
        val variants = SEARCH_SYNONYMS[word]?.let { listOf(word, it) } ?: listOf(word)
        variants.forEach { variant ->
            if (haystack.contains(variant)) {
                score += 3
            } else if (haystackWords.any { fuzzyWordsMatch(it, variant) }) {
                score += 1
            }
        }
    }
    return score
}

/** Port of `filterProducts()` ranking (source lines 3103-3121) — empty query returns the catalog unranked. */
fun filterProducts(products: List<Product>, rawQuery: String): List<Product> {
    val query = rawQuery.trim().lowercase()
    if (query.isEmpty()) return products
    val queryWords = query.split(Regex("\\s+")).filter { it.isNotEmpty() }
    return products
        .map { it to scoreProductAgainstQuery(it, queryWords) }
        .filter { (_, score) -> score > 0 }
        .sortedByDescending { (_, score) -> score }
        .map { (product, _) -> product }
}
