package com.swapnilchemicals.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/** Port of `APP.WA_NUMBER` / `buildWhatsAppUrl()` / `safeOpenNewTab()` (source lines 2439, 2514-2520). */
object WhatsApp {
    const val NUMBER = "919352470085"

    fun buildUrl(message: String): String = "https://wa.me/$NUMBER?text=${Uri.encode(message)}"

    /** Opens the WhatsApp chat (or a browser fallback) with [message] pre-filled, same intent as `window.open(url, "_blank")`. */
    fun openChat(context: Context, message: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(buildUrl(message)))
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "No app found to open WhatsApp", Toast.LENGTH_SHORT).show()
        }
    }
}
