package com.swapnilchemicals.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

// DataStore name mirrors `APP.CART_STORAGE_KEY = "sc_cart_auto"` (source line 2440) —
// the native replacement for `localStorage.setItem(APP.CART_STORAGE_KEY, ...)`.
private val Context.cartDataStore by preferencesDataStore(name = "sc_cart_auto")

class CartStore(private val context: Context) {
    private val cartKey = stringPreferencesKey("cart_json")
    private val json = Json { ignoreUnknownKeys = true }

    val snapshotFlow: Flow<CartSnapshot> = context.cartDataStore.data.map { prefs ->
        val raw = prefs[cartKey] ?: return@map CartSnapshot()
        // Mirrors `safeParseJSON()` (source lines 2505-2512) — corrupt/foreign data
        // falls back to an empty cart instead of crashing.
        runCatching { json.decodeFromString<CartSnapshot>(raw) }.getOrDefault(CartSnapshot())
    }

    suspend fun save(snapshot: CartSnapshot) {
        context.cartDataStore.edit { prefs ->
            prefs[cartKey] = json.encodeToString(snapshot)
        }
    }
}
