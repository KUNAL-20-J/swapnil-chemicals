package com.swapnilchemicals.app.util

import com.swapnilchemicals.app.data.Product
import com.swapnilchemicals.app.data.unitLabel
import com.swapnilchemicals.app.viewmodel.CartUiLine

/** Ports the WhatsApp message text built by `submitEnquiry()` and `submitCartEnquiry()` (source
 * lines 3294-3321, 2977-3010) — same emoji/field layout so messages look identical on the
 * business's WhatsApp. */
object EnquiryMessages {

    /** Single-product enquiry. The original's closing line reads "_Sent from website_" (line 3318);
     * this is a native app, so it reads "_Sent from the app_" instead — the only intentional wording change. */
    fun singleProduct(product: Product, qtyLabel: String, phone: String, details: String): String {
        val lines = mutableListOf(
            "🛒 *Enquiry — Swapnil Chemicals*",
            "📦 *Product:* ${product.name}",
            "📏 *Qty:* $qtyLabel",
            "📱 *Phone:* +91 $phone",
        )
        if (details.isNotBlank()) lines += "📝 *Details:* $details"
        lines += "_Sent from the app_"
        return lines.joinToString("\n")
    }

    fun cart(lines: List<CartUiLine>, details: String, phone: String): String {
        val body = mutableListOf("🛒 *Cart Enquiry — Swapnil Chemicals*", "")
        var grandTotal = 0
        lines.forEach { uiLine ->
            val product = uiLine.product
            val qty = uiLine.totalUnits
            val label = product.unitLabel()
            val lineTotal = product.price * qty
            grandTotal += lineTotal
            body += "📦 ${product.name} - Qty: $qty $label, Price: ${formatCurrency(product.price)} = Total: ${formatCurrency(lineTotal)}"
        }
        body += ""
        body += "📝 Details: $details"
        body += "📱 Phone: $phone"
        body += "💰 Grand Total: ${formatCurrency(grandTotal)}"
        return body.joinToString("\n")
    }
}
