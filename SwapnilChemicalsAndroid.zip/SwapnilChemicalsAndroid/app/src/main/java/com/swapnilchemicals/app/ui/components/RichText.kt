package com.swapnilchemicals.app.ui.components

import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle

private const val TAG_PHONE = "PHONE"
private const val TAG_EMAIL = "EMAIL"
private val LinkColor = Color(0xFF1D4ED8)

// One combined pass over `**bold**` markers, bare Indian mobile numbers and email addresses —
// see AssistantViewModel's `buildReply()` for why these three patterns are the only markup a
// reply can contain.
private val richTextTokenRegex =
    Regex("(\\*\\*(?<bold>.+?)\\*\\*)|(?<phone>\\b[6-9]\\d{9}\\b)|(?<email>[\\w.+-]+@[\\w-]+\\.[\\w.-]+)")

private fun buildRichAnnotatedString(raw: String): AnnotatedString = buildAnnotatedString {
    var lastIndex = 0
    for (match in richTextTokenRegex.findAll(raw)) {
        append(raw.substring(lastIndex, match.range.first))
        val bold = match.groups["bold"]?.value
        val phone = match.groups["phone"]?.value
        val email = match.groups["email"]?.value
        when {
            bold != null -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(bold) }
            phone != null -> {
                pushStringAnnotation(TAG_PHONE, phone)
                withStyle(SpanStyle(color = LinkColor, textDecoration = TextDecoration.Underline)) { append(phone) }
                pop()
            }
            email != null -> {
                pushStringAnnotation(TAG_EMAIL, email)
                withStyle(SpanStyle(color = LinkColor, textDecoration = TextDecoration.Underline)) { append(email) }
                pop()
            }
        }
        lastIndex = match.range.last + 1
    }
    append(raw.substring(lastIndex))
}

/**
 * Renders assistant/enquiry reply text that may contain `**bold**` markers, bare phone numbers
 * or an email address, making the phone/email tappable — replacing the original's inline
 * `<b>`/`<a href="tel:...">`/`<a href="mailto:...">` HTML (there is no HTML rendering in a
 * native app, so this is parsed with plain regex instead of a markup engine).
 */
@Composable
fun RichAssistantText(
    text: String,
    modifier: Modifier = Modifier,
    onPhoneClick: (String) -> Unit,
    onEmailClick: (String) -> Unit,
) {
    val annotated = remember(text) { buildRichAnnotatedString(text) }
    val style = MaterialTheme.typography.bodyMedium.copy(color = LocalContentColor.current)
    ClickableText(
        text = annotated,
        style = style,
        modifier = modifier,
        onClick = { offset ->
            annotated.getStringAnnotations(TAG_PHONE, offset, offset).firstOrNull()?.let {
                onPhoneClick(it.item)
                return@ClickableText
            }
            annotated.getStringAnnotations(TAG_EMAIL, offset, offset).firstOrNull()?.let {
                onEmailClick(it.item)
            }
        },
    )
}
