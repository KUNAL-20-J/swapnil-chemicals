package com.swapnilchemicals.app.ui.theme

import androidx.compose.ui.graphics.Color

// Ported from the site's :root custom properties and tailwind.config color extensions.
val BrandPrimary = Color(0xFF0F172A) // --primary
val BrandSecondary = Color(0xFF1E293B) // --secondary
val BrandAccent = Color(0xFF3B82F6) // --brand-accent
val BrandAccentDark = Color(0xFF1D4ED8) // --brand-accent-dark
val BrandSoft = Color(0xFFF8FAFC) // --soft

val AccentOrange = Color(0xFFEA580C)
val AccentOrangeDark = Color(0xFFC2410C)

val HeroBandTop = Color(0xFF4C1D95)
val HeroBandBottom = Color(0xFF6D28D9)

val WhatsAppGreen = Color(0xFF25D366)
val WhatsAppGreenDark = Color(0xFF128C7E)

val GPayGreen = Color(0xFF34A853)
val GPayGreenDark = Color(0xFF1A8A3C)

val DangerRed = Color(0xFFEF4444)
val DangerRedDark = Color(0xFFDC2626)

val SurfaceMuted = Color(0xFFF1F5F9)
val BorderMuted = Color(0xFFE2E8F0)
val TextMuted = Color(0xFF64748B)
