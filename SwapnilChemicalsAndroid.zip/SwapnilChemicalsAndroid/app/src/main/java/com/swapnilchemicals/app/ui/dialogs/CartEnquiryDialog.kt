package com.swapnilchemicals.app.ui.dialogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.swapnilchemicals.app.data.unitLabel
import com.swapnilchemicals.app.ui.components.ProductImage
import com.swapnilchemicals.app.ui.theme.WhatsAppGreen
import com.swapnilchemicals.app.util.formatCurrency
import com.swapnilchemicals.app.util.isValidIndianMobile
import com.swapnilchemicals.app.viewmodel.CartUiLine

/** Native equivalent of `openCartEnquiry()` / `submitCartEnquiry()` (source lines 2935-3010) —
 * same form as [EnquiryDialog] but listing every cart line instead of one product. */
@Composable
fun CartEnquiryDialog(
    lines: List<CartUiLine>,
    onDismiss: () -> Unit,
    onSubmit: (phone: String, details: String) -> Unit,
) {
    var details by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var showPhoneError by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()).padding(24.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top,
                ) {
                    Text("🛒 Cart Enquiry", style = MaterialTheme.typography.titleLarge)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                lines.forEach { uiLine ->
                    val product = uiLine.product
                    val unit = product.unitLabel()
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(modifier = Modifier.size(56.dp)) {
                            ProductImage(assetName = product.assetName, contentDescription = product.name)
                        }
                        Spacer(modifier = Modifier.padding(start = 12.dp))
                        Column {
                            Text(product.name, fontWeight = FontWeight.Bold)
                            Text(
                                "${uiLine.totalUnits} $unit × ${formatCurrency(product.price)}/$unit",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    label = { Text("Workshop Name & Address") },
                    placeholder = { Text("Any specific requirements…") },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    minLines = 2,
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = {
                        if (it.length <= 10 && it.all(Char::isDigit)) {
                            phone = it
                            showPhoneError = false
                        }
                    },
                    label = { Text("Your Phone Number *") },
                    placeholder = { Text("9876543210") },
                    isError = showPhoneError,
                    modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
                    singleLine = true,
                )
                if (showPhoneError) {
                    Text(
                        "Enter a valid 10-digit mobile number",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }

                Button(
                    onClick = {
                        if (!isValidIndianMobile(phone)) {
                            showPhoneError = true
                        } else {
                            onSubmit(phone.trim(), details.trim())
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp).padding(top = 18.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen, contentColor = Color.White),
                ) {
                    Text("Send Enquiry via WhatsApp", fontWeight = FontWeight.Bold)
                }
                Text(
                    "Your enquiry will be sent directly to Swapnil Chemicals on WhatsApp",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                )
            }
        }
    }
}
