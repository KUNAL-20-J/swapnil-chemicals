package com.swapnilchemicals.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.swapnilchemicals.app.data.Product
import com.swapnilchemicals.app.data.quantityChipLabel
import com.swapnilchemicals.app.data.quantityOptions
import com.swapnilchemicals.app.ui.theme.AccentOrange
import com.swapnilchemicals.app.util.formatCurrency

/** Port of `createProductCard()` + `selectQty()` (source lines 3012-3042). */
@Composable
fun ProductCard(
    product: Product,
    onAddToCart: (Product, Int) -> Unit,
    onOpenEnquiry: (Product) -> Unit,
    onCallClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val qtyOptions = remember(product.id) { product.quantityOptions() }
    val chipLabel = remember(product.id) { product.quantityChipLabel() }
    var selectedQty by remember(product.id) { mutableStateOf(qtyOptions.firstOrNull() ?: 1) }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .padding(20.dp),
                contentAlignment = Alignment.Center,
            ) {
                ProductImage(assetName = product.assetName, contentDescription = product.name)
            }

            Column(modifier = Modifier.padding(20.dp)) {
                Text(text = product.name, style = MaterialTheme.typography.titleLarge)
                Text(
                    text = product.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp, bottom = 12.dp),
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "${formatCurrency(product.price)}/${product.unit}",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = onCallClick) {
                            Icon(Icons.Filled.Call, contentDescription = "Call for ${product.name}")
                        }
                        OutlinedButton(onClick = { onOpenEnquiry(product) }) {
                            Icon(Icons.Filled.Assignment, contentDescription = null, modifier = Modifier.padding(end = 4.dp))
                            Text("Enquiry")
                        }
                    }
                }

                if (qtyOptions.isNotEmpty()) {
                    Text(
                        text = "Select Quantity",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 14.dp, bottom = 8.dp),
                    )
                    QtyChipRow(
                        options = qtyOptions,
                        unitLabel = chipLabel,
                        selected = selectedQty,
                        onSelect = { selectedQty = it },
                    )
                }

                Button(
                    onClick = { onAddToCart(product, if (qtyOptions.isNotEmpty()) selectedQty else 1) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentOrange, contentColor = Color.White),
                ) {
                    Icon(Icons.Filled.ShoppingCart, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
                    Text("Add to Cart")
                }
            }
        }
    }
}
