package com.swapnilchemicals.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.swapnilchemicals.app.data.Product
import com.swapnilchemicals.app.data.ProductCatalog
import com.swapnilchemicals.app.util.filterProducts
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/** Port of `initProductSearch()` / `filterProducts()` (source lines 3103-3130). */
class ProductViewModel : ViewModel() {
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    @OptIn(FlowPreview::class)
    val filteredProducts: StateFlow<List<Product>> = _query
        .debounce(150) // matches `debounce(() => filterProducts(input.value), 150)` (source line 3128)
        .map { q -> filterProducts(ProductCatalog.products, q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ProductCatalog.products)

    fun updateQuery(newQuery: String) {
        _query.value = newQuery
    }
}
