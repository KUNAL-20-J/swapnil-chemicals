package com.swapnilchemicals.app.ui.assistant

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.swapnilchemicals.app.ui.components.RichAssistantText
import com.swapnilchemicals.app.ui.theme.SurfaceMuted
import com.swapnilchemicals.app.ui.theme.WhatsAppGreen
import com.swapnilchemicals.app.viewmodel.AssistantMessage
import com.swapnilchemicals.app.viewmodel.AssistantRole
import com.swapnilchemicals.app.viewmodel.QuickReply

/**
 * Native equivalent of the assistant chat panel (source lines 2272-2309) — a `ModalBottomSheet`
 * (chat drawer) replaces the original's floating bottom-left panel.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantPanel(
    messages: List<AssistantMessage>,
    quickReplies: List<QuickReply>,
    sheetState: SheetState,
    isListening: Boolean,
    voiceAvailable: Boolean,
    onDismiss: () -> Unit,
    onSend: (String) -> Unit,
    onQuickReply: (String) -> Unit,
    onWhatsAppFallback: (String) -> Unit,
    onPhoneClick: (String) -> Unit,
    onEmailClick: (String) -> Unit,
    onMicClick: () -> Unit,
) {
    var input by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(modifier = Modifier.fillMaxWidth().heightIn(max = 560.dp).imePadding()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.SmartToy,
                        contentDescription = null,
                        modifier = Modifier
                            .size(38.dp)
                            .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                            .padding(8.dp),
                    )
                    Spacer(modifier = Modifier.padding(start = 12.dp))
                    Column {
                        Text("Swapnil AI Assistant", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Products, pricing & orders",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close assistant")
                }
            }
            HorizontalDivider()

            LazyColumn(
                modifier = Modifier.weight(1f, fill = false).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp),
            ) {
                items(messages, key = { it.id }) { msg ->
                    AssistantBubble(msg, onWhatsAppFallback, onPhoneClick, onEmailClick)
                }
            }

            if (quickReplies.isNotEmpty()) {
                LazyRow(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(quickReplies) { qr ->
                        AssistChip(onClick = { onQuickReply(qr.query) }, label = { Text(qr.label) })
                    }
                }
            }

            HorizontalDivider()
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type your question…") },
                    singleLine = true,
                )
                if (voiceAvailable) {
                    IconButton(onClick = onMicClick) {
                        Icon(
                            imageVector = if (isListening) Icons.Filled.MicOff else Icons.Filled.Mic,
                            contentDescription = if (isListening) "Stop listening" else "Ask by voice",
                            tint = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                IconButton(
                    onClick = {
                        if (input.isNotBlank()) {
                            onSend(input)
                            input = ""
                        }
                    },
                ) {
                    Icon(Icons.Filled.Send, contentDescription = "Send message", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun AssistantBubble(
    msg: AssistantMessage,
    onWhatsAppFallback: (String) -> Unit,
    onPhoneClick: (String) -> Unit,
    onEmailClick: (String) -> Unit,
) {
    val isBot = msg.role == AssistantRole.BOT
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (isBot) Arrangement.Start else Arrangement.End,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 280.dp)
                    .background(
                        color = if (isBot) SurfaceMuted else MaterialTheme.colorScheme.primary,
                        shape = RoundedCornerShape(14.dp),
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                if (isBot) {
                    RichAssistantText(text = msg.text, onPhoneClick = onPhoneClick, onEmailClick = onEmailClick)
                } else {
                    Text(msg.text, color = Color.White)
                }
            }
        }
        if (msg.whatsAppFallbackQuery != null) {
            Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Start) {
                AssistChip(
                    onClick = { onWhatsAppFallback(msg.whatsAppFallbackQuery) },
                    label = { Text("Ask on WhatsApp") },
                    leadingIcon = { Icon(Icons.Filled.Chat, contentDescription = null) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = WhatsAppGreen,
                        labelColor = Color.White,
                        leadingIconContentColor = Color.White,
                    ),
                )
            }
        }
    }
}
