package com.swapnilchemicals.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

/**
 * Looks up `res/drawable/<assetName>` at runtime (see [com.swapnilchemicals.app.data.Product.assetName])
 * and falls back to a placeholder icon when the real product photo hasn't been supplied yet — see the
 * project README for the exact filenames expected for each product (the source site's images
 * — "Dashboard Polish.jpeg" etc — were not present anywhere on disk, so this ships with placeholders).
 */
@Composable
fun ProductImage(assetName: String, contentDescription: String?, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val resId = remember(assetName) {
        context.resources.getIdentifier(assetName, "drawable", context.packageName)
    }
    if (resId != 0) {
        Image(
            painter = painterResource(id = resId),
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = ContentScale.Fit,
        )
    } else {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Filled.ImageIcon,
                contentDescription = contentDescription,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.outline,
            )
        }
    }
}
