package com.swapnilchemicals.app.util

import java.text.NumberFormat
import java.util.Locale

/** Port of the `Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 })` formatter (source line 2528-2532). */
private val currencyFormatter: NumberFormat by lazy {
    NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
        maximumFractionDigits = 0
    }
}

fun formatCurrency(amount: Number): String = currencyFormatter.format(amount)
