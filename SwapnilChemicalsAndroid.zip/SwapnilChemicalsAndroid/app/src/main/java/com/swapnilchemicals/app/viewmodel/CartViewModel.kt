package com.swapnilchemicals.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.swapnilchemicals.app.data.CartLine
import com.swapnilchemicals.app.data.CartSnapshot
import com.swapnilchemicals.app.data.CartStore
import com.swapnilchemicals.app.data.Product
import com.swapnilchemicals.app.data.ProductCatalog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** One rendered cart row — a [CartLine] joined with its [Product] (looked up once, not re-resolved per read). */
data class CartUiLine(val line: CartLine, val product: Product) {
    val totalUnits: Int get() = line.selectedQty * line.quantity
    val lineTotal: Int get() = product.price * totalUnits
}

data class CartUiState(val lines: List<CartUiLine> = emptyList()) {
    val totalItems: Int get() = lines.sumOf { it.line.quantity }
    val grandTotal: Int get() = lines.sumOf { it.lineTotal }
    val isEmpty: Boolean get() = lines.isEmpty()
}

/**
 * Port of the module-level `cart` object and its mutator functions (source lines 2446,
 * 2664-2799, 2858-2866). Every mutation both updates in-memory state immediately (like the
 * original calling `updateCartUI()` right after mutating `cart`) and persists to [CartStore]
 * (replacing `localStorage.setItem(...)`).
 */
class CartViewModel(application: Application) : AndroidViewModel(application) {
    private val store = CartStore(application)

    private val _state = MutableStateFlow(CartUiState())
    val state: StateFlow<CartUiState> = _state.asStateFlow()

    init {
        // Restores the cart on launch, mirroring the `DOMContentLoaded` restore (source lines 3727-3731).
        viewModelScope.launch {
            store.snapshotFlow.collect { snapshot ->
                _state.value = CartUiState(
                    lines = snapshot.lines.mapNotNull { line ->
                        ProductCatalog.byId[line.productId]?.let { CartUiLine(line, it) }
                    },
                )
            }
        }
    }

    /** Port of `addToCart()` (source lines 2664-2697), minus the `flyToCart` DOM animation. */
    fun addToCart(product: Product, selectedQty: Int) {
        val key = "${product.id}_$selectedQty"
        updateLines { current ->
            val idx = current.indexOfFirst { it.line.key == key }
            if (idx >= 0) {
                current.toMutableList().apply {
                    val existing = this[idx]
                    this[idx] = existing.copy(line = existing.line.copy(quantity = existing.line.quantity + 1))
                }
            } else {
                current + CartUiLine(CartLine(product.id, selectedQty, quantity = 1), product)
            }
        }
    }

    /** Port of `changeCartQty()` (source lines 2791-2799) — refuses to go below 1 rather than removing the line. */
    fun changeQuantity(key: String, delta: Int) {
        updateLines { current ->
            current.map { uiLine ->
                if (uiLine.line.key != key) return@map uiLine
                val newQty = uiLine.line.quantity + delta
                if (newQty < 1) uiLine else uiLine.copy(line = uiLine.line.copy(quantity = newQty))
            }
        }
    }

    /** Port of `confirmRemoveFromCart()`'s actual removal step (source lines 2819-2856) — the confirm dialog itself is UI state. */
    fun removeLine(key: String) {
        updateLines { current -> current.filterNot { it.line.key == key } }
    }

    /** Port of `clearCart()` (source lines 2858-2866). */
    fun clear() {
        updateLines { emptyList() }
    }

    fun lineByKey(key: String): CartUiLine? = _state.value.lines.firstOrNull { it.line.key == key }

    private fun updateLines(transform: (List<CartUiLine>) -> List<CartUiLine>) {
        val newLines = transform(_state.value.lines)
        _state.value = CartUiState(newLines)
        viewModelScope.launch { store.save(CartSnapshot(newLines.map { it.line })) }
    }
}
