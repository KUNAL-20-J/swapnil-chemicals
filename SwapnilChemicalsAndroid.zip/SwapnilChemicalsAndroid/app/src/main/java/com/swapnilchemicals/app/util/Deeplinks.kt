package com.swapnilchemicals.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Native equivalents of the plain `tel:` / `mailto:` / `upi://` anchor links in the original
 * markup (source lines 1853-1854, 1892-1894, 2148-2150 etc). `ACTION_DIAL` (not `ACTION_CALL`)
 * is used deliberately — it opens the dialer pre-filled, same as a browser `tel:` link, and needs
 * no `CALL_PHONE` permission.
 */
object Deeplinks {
    /** Payee details from the Contact section's UPI link (source line 2148). */
    const val UPI_PAYEE_VPA = "boism-9352470085@boi"
    const val UPI_PAYEE_NAME = "Swapnil Chemicals"

    fun dial(context: Context, phoneNumber: String) =
        safeStart(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber")))

    fun email(context: Context, address: String) =
        safeStart(context, Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$address")))

    fun payViaUpi(context: Context) {
        val uri = Uri.parse("upi://pay")
            .buildUpon()
            .appendQueryParameter("pa", UPI_PAYEE_VPA)
            .appendQueryParameter("pn", UPI_PAYEE_NAME)
            .appendQueryParameter("cu", "INR")
            .build()
        safeStart(context, Intent(Intent.ACTION_VIEW, uri), notFoundMessage = "No UPI app found — pay via the QR code instead")
    }

    private fun safeStart(context: Context, intent: Intent, notFoundMessage: String = "No app found to handle this action") {
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, notFoundMessage, Toast.LENGTH_SHORT).show()
        }
    }
}
