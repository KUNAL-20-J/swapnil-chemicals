package com.swapnilchemicals.app.util

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Native equivalent of `attachVoiceInput()` / `createSpeechRecognizer()` (source lines 3132-3179).
 * Uses the on-device [SpeechRecognizer] (not the system dialog `RecognizerIntent` launcher) so the
 * calling button can drive its own "listening" pulse state, matching `.voice-btn.listening` in the
 * original CSS/JS rather than handing off to a system picker UI.
 *
 * Requires the `RECORD_AUDIO` permission to already be granted — callers must request it first
 * (the original has no such step because browsers prompt for microphone access automatically).
 */
class VoiceRecognitionController(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(
        onListeningChange: (Boolean) -> Unit,
        onResult: (String) -> Unit,
        onError: () -> Unit = {},
    ) {
        if (!isAvailable()) {
            onError()
            return
        }
        stop()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                onListeningChange(true)
            }

            override fun onResults(results: Bundle?) {
                onListeningChange(false)
                val transcript = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (transcript.isNotEmpty()) onResult(transcript)
            }

            override fun onError(error: Int) {
                // Microphone denied or nothing heard — fail quietly, matching `recognizer.onerror`
                // (source line 3169-3171): the input stays editable by hand.
                onListeningChange(false)
                onError()
            }

            override fun onEndOfSpeech() {
                onListeningChange(false)
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        r.startListening(intent)
    }

    fun stop() {
        recognizer?.destroy()
        recognizer = null
    }
}
