package com.swapnilchemicals.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

// The original site pins `color-scheme: light` and a light-only palette (line ~198
// of the source), so this app follows the same light-first design intentionally
// rather than deriving a separate dark palette.
private val LightColors = lightColorScheme(
    primary = BrandAccent,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    secondary = AccentOrange,
    onSecondary = androidx.compose.ui.graphics.Color.White,
    background = BrandSoft,
    surface = androidx.compose.ui.graphics.Color.White,
    error = DangerRed,
)

private val DarkColors = darkColorScheme(
    primary = BrandAccent,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    secondary = AccentOrange,
    onSecondary = androidx.compose.ui.graphics.Color.White,
    background = BrandPrimary,
    surface = BrandSecondary,
    error = DangerRed,
)

@Composable
fun SwapnilChemicalsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content,
    )
}
