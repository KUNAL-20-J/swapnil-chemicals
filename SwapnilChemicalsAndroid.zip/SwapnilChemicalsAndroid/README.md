# Swapnil Chemicals — Android app

A native Android (Kotlin + Jetpack Compose) rewrite of the Swapnil Chemicals marketing site
(`index14-09-266copyy----.php`). This is a full rebuild, not a WebView wrapper — see the
per-feature source-line references in code comments throughout the project for how each part
maps back to the original HTML/CSS/JS.

## Building & running

This was written in a sandbox with **no Android SDK installed**, so it has not been compiled or
run here — only reviewed by hand. To build it:

1. Open the `SwapnilChemicalsAndroid/` folder in Android Studio (Koala or newer).
2. Let Gradle sync — Android Studio will offer to generate the Gradle wrapper JAR
   (`gradle/wrapper/gradle-wrapper.jar` is intentionally not included, since it's a binary file)
   the first time you sync or run `gradle wrapper` from the IDE's terminal.
3. Run on a device or emulator (**API 24+**).

If Gradle reports a version mismatch or a missing/renamed dependency coordinate, it's most likely
a library version that's moved on since this was written — bump it in `gradle/libs.versions.toml`
and re-sync; the rest of the code doesn't depend on exact versions.

A few Material icon names (`Icons.Filled.SmartToy`, `LocalCarWash`, `QrCode2`, `Badge`,
`VerifiedUser`, `Receipt`, `ContentCopy`, `ChecklistRtl`-style icons) were chosen from memory and
not verified against a live `material-icons-extended` artifact — if the compiler flags one as
unresolved, swap it for the nearest equivalent in `androidx.compose.material.icons.filled.*`.

## Test plan (do this after building)

- Search the product grid (try "towel", "polish", a misspelling like "poliish", and a synonym
  like "shine") and confirm fuzzy/synonym matching works, then try the mic button.
- Add a couple of products to the cart at different quantities, open the cart, change quantities,
  remove one (confirm dialog appears), clear the cart.
- Open a product's "Enquiry" dialog and the cart's WhatsApp enquiry flow — confirm the phone
  validation (must be a 10-digit number starting 6-9) and that WhatsApp opens with the message
  pre-filled.
- Tap "Pay via UPI / GPay" in the Contact section — confirm it opens an installed UPI app (or
  shows the "no UPI app" toast if none is installed) — and check the generated QR code scans
  correctly in a UPI app.
- Open the AI assistant, try the quick-reply chips, a few free-text questions ("what do you
  sell", "bulk orders", "where are you based"), and an off-topic question to see the WhatsApp
  fallback chip. Try its mic button too.
- Rotate the device / resize (if using a foldable or resizable emulator) to sanity-check layout.

## Known gaps vs. the original site (intentional — see the approved plan)

- **No real product photos or logo.** The site's images (`Dashboard Polish.jpeg`, `Tyre
  Polish.jpeg`, `SC Logo.jpg`, etc.) were not present anywhere on disk when this was built — only
  the source file itself existed. Product cards fall back to a placeholder icon
  (`ui/components/ProductImage.kt`) and the launcher icon is a plain placeholder mark
  (`res/drawable/ic_launcher_foreground.xml`).

  **To add real photos**, drop image files into `app/src/main/res/drawable/` using these exact
  names (any of `.png`/`.jpg`/`.webp`, no code changes needed):
  | Product | Expected file name |
  |---|---|
  | Dashboard Polish | `dashboard_polish` |
  | Tyre Polish | `tyre_polish` |
  | Car Foaming Wash | `car_foaming_wash` |
  | Interior Cleaner | `interior_cleaner` |
  | Glass Cleaner | `glass_cleaner` |
  | Foaming Gun | `foaming_gun` |
  | Micro Towel (₹70) | `micro_towel_1` |
  | Micro Towel (₹110) | `micro_towel_2` |
  | Micro Towel (₹130) | `micro_towel_3` |

  Android resource file names must be lowercase with underscores only — that's already how the
  names above are spelled.

- **No WebView / browser-only effects.** Scroll-reveal animations, the CSS grain background, and
  the DOM-clone "fly to cart" animation don't have native equivalents and were replaced with
  standard Compose transitions or dropped as purely cosmetic.
- The cart's "Pay via GPay" button is **not** a payment action in the original either — it opens
  the WhatsApp cart-enquiry flow (its label becomes "Enquiry ₹total"). That behavior is preserved
  as-is. Actual UPI/GPay payment only happens from the Contact section's "Pay via UPI / GPay"
  button and QR code.
- Voice input uses Android's on-device `SpeechRecognizer` and requires the `RECORD_AUDIO`
  permission (requested the first time a mic button is tapped) — the original needed no such step
  because browsers prompt for microphone access automatically.
