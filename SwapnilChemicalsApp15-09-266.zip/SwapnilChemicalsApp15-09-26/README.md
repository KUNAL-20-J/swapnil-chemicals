# Swapnil Chemicals — Android App

Native Android (Kotlin) wrapper around the existing `index.html` site. It loads
the bundled HTML/CSS/JS through the `androidx.webkit.WebViewAssetLoader`
virtual `https://appassets.androidplatform.net/assets/...` domain (not
`file://`), so the page's own CSP (`script-src 'self'`, `style-src 'self'`,
etc.) resolves exactly as it does when served from a real https origin.

## What's implemented

- WebView with JS + DOM storage enabled (needed for the cart state).
- `tel:` links open the dialer; `mailto:`, `upi:` (Google Pay/PhonePe) and
  every `http(s)` link that isn't our own bundled page (WhatsApp `wa.me`
  enquiry links, outbound links) open in the appropriate external app instead
  of inside the WebView.
- Mic permission bridging for the page's voice-search / AI assistant button
  (Web Speech API → Android `RECORD_AUDIO` runtime permission).
- Back button drives WebView history before exiting the app.
- Pull-to-refresh, and a basic "you're offline" screen with retry.

## Before you build

1. **Drop in the real site files** under `app/src/main/assets/`:
   - `index.html` (the complete file — see note below)
   - `SC Logo.jpg` and any other images the page references by relative path
   - Any separate `.css`/`.js` files if you split them out later

   The page currently pulls Tailwind, Font Awesome and Google Fonts from
   their CDNs at runtime (`<script src="https://cdn.tailwindcss.com">` etc.),
   so **the app needs an active internet connection to render correctly**,
   even though the HTML itself is bundled locally. If you want the app to
   work fully offline, those three CDN dependencies need to be replaced with
   files bundled in `assets/` as well — ask if you want that done.

2. **Replace the placeholder app icon.** `res/mipmap-*/ic_launcher.png` right
   now is a generated navy circle with "SC" — a stand-in, not your real logo.
   In Android Studio: right-click `res` → New → Image Asset → pick
   `SC Logo.jpg` as the source, and it will regenerate all densities
   correctly (including the round variant).

3. **Change the package name** if `com.swapnilchemicals.app` isn't the id you
   want to publish under (`applicationId` in `app/build.gradle.kts` and the
   `namespace`, plus the folder path under `app/src/main/java/`).

## Build

Open the `SwapnilChemicalsApp` folder in Android Studio (it will generate the
Gradle wrapper jar on first sync), or from the command line once you have the
Android SDK installed:

```bash
./gradlew assembleDebug
```

The debug APK lands in `app/build/outputs/apk/debug/`.
