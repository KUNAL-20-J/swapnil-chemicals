# Add project specific ProGuard rules here.
-keepclassmembers class com.swapnilchemicals.app.WebAppInterface {
    public *;
}
