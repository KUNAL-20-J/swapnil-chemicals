package com.swapnilchemicals.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.http.SslError
import android.os.Bundle
import android.view.View
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewFeature
import com.google.android.material.snackbar.Snackbar
import com.swapnilchemicals.app.databinding.ActivityMainBinding

/**
 * Loads the bundled site (app/src/main/assets/index.html) through the
 * https://appassets.androidplatform.net virtual domain so the page's own
 * `script-src 'self'` / `style-src 'self'` CSP resolves correctly, exactly
 * as it does when the site is served from a real https origin.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var pendingPermissionRequest: PermissionRequest? = null

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    private val micPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { granted ->
            val request = pendingPermissionRequest
            pendingPermissionRequest = null
            if (request == null) return@registerForActivityResult
            if (granted) {
                request.grant(request.resources)
            } else {
                request.deny()
                Snackbar.make(binding.root, R.string.mic_permission_denied, Snackbar.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWebView()
        setupSwipeRefresh()
        setupBackNavigation()

        binding.retryButton.setOnClickListener { loadHome() }

        loadHome()
    }

    private fun loadHome() {
        binding.offlineView.visibility = View.GONE
        binding.swipeRefresh.visibility = View.VISIBLE
        binding.webView.loadUrl(START_URL)
    }

    private fun setupWebView() {
        val webView = binding.webView
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.setSupportZoom(false)
        settings.builtInZoomControls = false
        settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT

        // Site is bundled locally: no need to reach the filesystem or other origins.
        settings.allowFileAccess = false
        settings.allowContentAccess = false

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(settings, WebSettingsCompat.FORCE_DARK_OFF)
        }

        webView.webViewClient = SiteWebViewClient()
        webView.webChromeClient = SiteWebChromeClient()
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            binding.webView.reload()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (binding.webView.canGoBack()) {
                        binding.webView.goBack()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            },
        )
    }

    private inner class SiteWebViewClient : android.webkit.WebViewClient() {

        override fun shouldInterceptRequest(
            view: WebView,
            request: WebResourceRequest,
        ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val uri = request.url
            val host = uri.host ?: ""

            // Keep navigation on our own bundled origin inside the WebView.
            if (host == WebViewAssetLoader.DEFAULT_DOMAIN) {
                return false
            }

            val action = if (uri.scheme == "tel") Intent.ACTION_DIAL else Intent.ACTION_VIEW
            openExternally(Intent(action, uri))
            return true
        }

        override fun onReceivedError(
            view: WebView,
            request: WebResourceRequest,
            error: WebResourceError,
        ) {
            super.onReceivedError(view, request, error)
            if (request.isForMainFrame) {
                binding.swipeRefresh.visibility = View.GONE
                binding.offlineView.visibility = View.VISIBLE
            }
        }

        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
            // Do not silently trust bad certificates; defer to default (cancel) behaviour.
            super.onReceivedSslError(view, handler, error)
        }

        override fun onPageFinished(view: WebView, url: String?) {
            super.onPageFinished(view, url)
            binding.swipeRefresh.isRefreshing = false
        }
    }

    private fun openExternally(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Snackbar.make(binding.root, e.localizedMessage ?: "No app found to handle this link", Snackbar.LENGTH_SHORT).show()
        }
    }

    private inner class SiteWebChromeClient : WebChromeClient() {

        // The page's voice-search / AI assistant mic button uses the Web Speech API,
        // which WebView surfaces as a RESOURCE_AUDIO_CAPTURE permission request.
        override fun onPermissionRequest(request: PermissionRequest) {
            val needsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
            if (!needsAudio) {
                request.deny()
                return
            }

            val hasAudioPermission = ContextCompat.checkSelfPermission(
                this@MainActivity,
                Manifest.permission.RECORD_AUDIO,
            ) == PackageManager.PERMISSION_GRANTED

            if (hasAudioPermission) {
                request.grant(request.resources)
            } else {
                pendingPermissionRequest = request
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    companion object {
        private val START_URL = "https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/index.html"
    }
}
